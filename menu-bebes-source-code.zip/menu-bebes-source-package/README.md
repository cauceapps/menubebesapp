# Menú bebés — código fuente completo

Este paquete contiene el proyecto completo de Menú bebés: frontend React, servidor Node/Express, API tRPC, autenticación Manus, esquema Drizzle y configuración de base de datos.

## Requisitos

- Node.js 20 o superior
- pnpm 10 o superior
- Una base de datos MySQL/TiDB compatible
- Variables de entorno del proyecto (`DATABASE_URL`, `JWT_SECRET`, credenciales OAuth y demás variables indicadas por el proveedor)

## Instalación

```bash
pnpm install
pnpm run check
pnpm run build
pnpm start
```

## Desarrollo local

```bash
pnpm install
pnpm dev
```

## Despliegue

Este paquete no funciona como un sitio HTML estático sin más. Para conservar autenticación, persistencia, favoritos, perfil, menú semanal y lista de compras necesitas un hosting que ejecute Node.js y permita configurar variables de entorno y base de datos, por ejemplo Render, Railway, Fly.io, una VPS o un servicio equivalente.

GitHub puede alojar el repositorio, pero GitHub Pages no ejecuta el backend Node.js. Para publicar la app completa desde GitHub necesitas conectar el repositorio a un servicio de despliegue compatible.

## Seguridad

No subas archivos `.env`, contraseñas, tokens, claves privadas ni credenciales de base de datos al repositorio.
