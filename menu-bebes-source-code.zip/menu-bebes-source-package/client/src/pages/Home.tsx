import { Fragment, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  Baby,
  BookOpen,
  CalendarDays,
  CalendarRange,
  Check,
  ChevronDown,
  Clock3,
  Download,
  Heart,
  LogIn,
  LogOut,
  Plus,
  Trash2,
  Menu,
  RefreshCw,
  Search,
  Settings2,
  ShoppingBasket,
  Sparkles,
  Star,
  Utensils,
  X,
} from "lucide-react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

const image = (name: string) => `/manus-storage/${name}`;

function BrandLogo() {
  return <span className="flex items-center gap-3"><span className="brand-mark"><Baby size={20} strokeWidth={2.5} /></span><span><span className="block font-display text-lg font-semibold tracking-tight text-[#23352f]">Menú bebés</span><span className="hidden text-[10px] font-semibold uppercase tracking-[0.16em] text-[#82917d] sm:block">qué darle hoy, resuelto</span></span></span>;
}

type MealKey = "desayuno" | "almuerzo" | "cena";
type Method = "BLW" | "Triturado" | "Combinado";
type Stage = "6 a 8 meses" | "9 a 12 meses" | "12 meses o más";
type Category = "Frutas" | "Verduras" | "Proteínas" | "Cereales y otros";

type Recipe = {
  id: string;
  title: string;
  stage: Stage;
  meals: MealKey[];
  method: Method[];
  minutes: number;
  texture: string;
  ingredients: string[];
  items: { name: string; category: Category; quantity: string }[];
  tags: string[];
  image: string;
  description: string;
  preparation: string;
  yield?: number;
};

type WeekDay = { day: string; meals: Record<MealKey, string> };
type Profile = { stage: Stage; method: Method; avoid: string[]; available: string[]; time: string };

type ShoppingItem = { name: string; category: Category; quantity: string; checked: boolean };

const stages: Stage[] = ["6 a 8 meses", "9 a 12 meses", "12 meses o más"];
const methods: Method[] = ["BLW", "Triturado", "Combinado"];
const times = ["Menos de 15 min", "15 a 30 min", "Más de 30 min"];
const avoidOptions = ["Huevo", "Lácteos", "Gluten", "Pollo", "Legumbres", "Tomate"];
const availableOptions = ["Avena", "Banano", "Zanahoria", "Calabacín", "Arroz", "Aguacate", "Huevo", "Lentejas"];

const recipes: Recipe[] = [
  {
    id: "avena-banano",
    title: "Avena cremosa con banano",
    stage: "6 a 8 meses",
    meals: ["desayuno"],
    method: ["Triturado", "Combinado"],
    minutes: 10,
    texture: "Cremosa y suave",
    ingredients: ["Avena", "Banano", "Agua"],
    items: [
      { name: "Avena", category: "Cereales y otros", quantity: "½ taza" },
      { name: "Banano", category: "Frutas", quantity: "2 unidades" },
    ],
    tags: ["sin azúcar", "desayuno"],
    image: image("bowl-avena_e5557c47.jpg"),
    description: "Una base suave para empezar la mañana con ingredientes sencillos.",
    preparation: "Cocina la avena con agua hasta que esté muy blanda. Añade el banano machacado y ajusta la textura.",
  },
  {
    id: "verduras-pollo",
    title: "Verduras suaves con pollo",
    stage: "6 a 8 meses",
    meals: ["almuerzo", "cena"],
    method: ["Triturado", "Combinado"],
    minutes: 25,
    texture: "Blanda y húmeda",
    ingredients: ["Zanahoria", "Calabacín", "Pollo"],
    items: [
      { name: "Zanahoria", category: "Verduras", quantity: "2 unidades" },
      { name: "Calabacín", category: "Verduras", quantity: "1 unidad" },
      { name: "Pollo", category: "Proteínas", quantity: "200 g" },
    ],
    tags: ["hierro", "almuerzo"],
    image: image("bowl-pollo_d8f93e4e.jpg"),
    description: "Verduras tiernas con pollo deshebrado para una comida completa y fácil de ajustar.",
    preparation: "Cocina todos los ingredientes hasta que estén tiernos. Tritura o deshebra según el método elegido.",
  },
  {
    id: "pasta-calabacin",
    title: "Pasta suave con calabacín",
    stage: "9 a 12 meses",
    meals: ["almuerzo", "cena"],
    method: ["BLW", "Combinado"],
    minutes: 20,
    texture: "Muy blanda",
    ingredients: ["Pasta", "Calabacín", "Aceite de oliva"],
    items: [
      { name: "Pasta", category: "Cereales y otros", quantity: "1 taza" },
      { name: "Calabacín", category: "Verduras", quantity: "1 unidad" },
    ],
    tags: ["familiar", "cena"],
    image: image("blw-pasta_ae5e2591.jpg"),
    description: "Una opción familiar que aprovecha el calabacín y se adapta a distintas texturas.",
    preparation: "Cocina la pasta un poco más de lo habitual. Saltea el calabacín hasta que esté muy tierno y mezcla.",
  },
  {
    id: "tortitas-avena",
    title: "Tortitas blandas de avena",
    stage: "9 a 12 meses",
    meals: ["desayuno", "merienda" as MealKey],
    method: ["BLW", "Combinado"],
    minutes: 15,
    texture: "Blanda y fácil de tomar",
    ingredients: ["Avena", "Banano", "Huevo"],
    items: [
      { name: "Avena", category: "Cereales y otros", quantity: "½ taza" },
      { name: "Banano", category: "Frutas", quantity: "1 unidad" },
      { name: "Huevo", category: "Proteínas", quantity: "1 unidad" },
    ],
    tags: ["sin azúcar", "BLW"],
    image: image("blw-pancakes_efbbb384.jpg"),
    description: "Tiras blandas para una mañana práctica, con tres ingredientes fáciles de encontrar.",
    preparation: "Mezcla el banano, la avena y el huevo. Cocina porciones pequeñas hasta que queden firmes pero blandas.",
  },
  {
    id: "lentejas-verduras",
    title: "Lentejas con camote y brócoli",
    stage: "9 a 12 meses",
    meals: ["almuerzo", "cena"],
    method: ["Triturado", "Combinado"],
    minutes: 30,
    texture: "Espesa y suave",
    ingredients: ["Lentejas", "Camote", "Brócoli"],
    items: [
      { name: "Lentejas", category: "Proteínas", quantity: "1 taza" },
      { name: "Camote", category: "Verduras", quantity: "1 unidad" },
      { name: "Brócoli", category: "Verduras", quantity: "1 cabeza pequeña" },
    ],
    tags: ["hierro", "sin carne"],
    image: image("bowl-lentejas_403fa9bb.jpg"),
    description: "Una combinación espesa y reconfortante para variar las proteínas de la semana.",
    preparation: "Cocina las lentejas y el camote hasta que se deshagan. Añade brócoli muy tierno y ajusta la textura.",
  },
  {
    id: "arroz-verduras",
    title: "Arroz suave con verduras",
    stage: "9 a 12 meses",
    meals: ["almuerzo", "cena"],
    method: ["BLW", "Triturado", "Combinado"],
    minutes: 25,
    texture: "Húmeda y suave",
    ingredients: ["Arroz", "Arvejas", "Camote", "Zanahoria"],
    items: [
      { name: "Arroz", category: "Cereales y otros", quantity: "1 taza" },
      { name: "Arvejas", category: "Verduras", quantity: "½ taza" },
      { name: "Camote", category: "Verduras", quantity: "1 unidad" },
      { name: "Zanahoria", category: "Verduras", quantity: "2 unidades" },
    ],
    tags: ["aprovecha ingredientes", "familiar"],
    image: image("bowl-arroz_7a3869cb.jpg"),
    description: "Arroz húmedo con verduras blandas para cocinar una vez y aprovechar en dos comidas.",
    preparation: "Cocina el arroz con las verduras hasta que todo quede muy tierno. Sirve aplastado o en porciones blandas.",
  },
  {
    id: "aguacate-huevo",
    title: "Huevo suave con aguacate",
    stage: "9 a 12 meses",
    meals: ["desayuno", "almuerzo"],
    method: ["BLW", "Combinado"],
    minutes: 12,
    texture: "Suave y húmeda",
    ingredients: ["Huevo", "Aguacate", "Tomate"],
    items: [
      { name: "Huevo", category: "Proteínas", quantity: "2 unidades" },
      { name: "Aguacate", category: "Frutas", quantity: "1 unidad" },
      { name: "Tomate", category: "Verduras", quantity: "1 unidad" },
    ],
    tags: ["rápido", "desayuno"],
    image: image("bowl-huevo_c7d6d2e0.jpg"),
    description: "Una comida rápida para los días en que hay poco tiempo y quieres usar aguacate maduro.",
    preparation: "Cocina el huevo hasta que esté completamente hecho. Sirve con aguacate machacado y tomate muy blando.",
  },
  {
    id: "camote-garbanzos",
    title: "Camote con garbanzos",
    stage: "12 meses o más",
    meals: ["almuerzo", "cena"],
    method: ["Triturado", "Combinado"],
    minutes: 25,
    texture: "Cremosa y espesa",
    ingredients: ["Camote", "Garbanzos", "Coliflor"],
    items: [
      { name: "Camote", category: "Verduras", quantity: "1 unidad" },
      { name: "Garbanzos", category: "Proteínas", quantity: "1 taza" },
      { name: "Coliflor", category: "Verduras", quantity: "½ cabeza" },
    ],
    tags: ["sin carne", "cremosa"],
    image: image("bowl-lentejas_403fa9bb.jpg"),
    description: "Camote y garbanzos en una textura cremosa, con coliflor muy tierna al lado.",
    preparation: "Cocina camote, garbanzos y coliflor hasta que estén blandos. Tritura o aplasta según preferencia.",
  },
  {
    id: "manzana-pera",
    title: "Compota de manzana y pera",
    stage: "6 a 8 meses",
    meals: ["desayuno"],
    method: ["Triturado", "Combinado"],
    minutes: 15,
    texture: "Cremosa",
    ingredients: ["Manzana", "Pera"],
    items: [
      { name: "Manzana", category: "Frutas", quantity: "2 unidades" },
      { name: "Pera", category: "Frutas", quantity: "1 unidad" },
    ],
    tags: ["sin azúcar", "fruta"],
    image: image("bowl-fruta_7845bc7e.jpg"),
    description: "Fruta cocida hasta quedar suave, sin azúcar añadida y fácil de preparar.",
    preparation: "Pela y corta la fruta. Cocina con un poco de agua hasta que esté tierna y aplasta.",
  },
  {
    id: "quinua-verduras",
    title: "Quinua con calabacín y camote",
    stage: "12 meses o más",
    meals: ["almuerzo", "cena"],
    method: ["BLW", "Triturado", "Combinado"],
    minutes: 30,
    texture: "Suave y húmeda",
    ingredients: ["Quinua", "Calabacín", "Camote"],
    items: [
      { name: "Quinua", category: "Cereales y otros", quantity: "1 taza" },
      { name: "Calabacín", category: "Verduras", quantity: "1 unidad" },
      { name: "Camote", category: "Verduras", quantity: "1 unidad" },
    ],
    tags: ["familiar", "variedad"],
    image: image("bowl-quinoa_b1e81455.jpg"),
    description: "Quinua suave con verduras para sumar variedad sin complicar la compra.",
    preparation: "Lava y cocina la quinua. Cocina las verduras hasta que estén tiernas y mezcla o sirve por separado.",
  },
];


const moreRecipes: Recipe[] = [
  { id: "papilla-pera-avena", title: "Papilla tibia de pera y avena", stage: "6 a 8 meses", meals: ["desayuno"], method: ["Triturado", "Combinado"], minutes: 12, texture: "Sedosa", ingredients: ["Pera", "Avena"], items: [{ name: "Pera", category: "Frutas", quantity: "2 unidades" }, { name: "Avena", category: "Cereales y otros", quantity: "½ taza" }], tags: ["suave", "sin azúcar"], image: image("bowl-fruta_7845bc7e.jpg"), description: "Pera cocida con avena para variar la primera comida del día.", preparation: "Cocina la pera y la avena con agua hasta que estén blandas. Tritura hasta conseguir la textura deseada." },
  { id: "platano-aguacate", title: "Crema de banano y aguacate", stage: "6 a 8 meses", meals: ["desayuno"], method: ["Triturado", "Combinado"], minutes: 8, texture: "Cremosa", ingredients: ["Banano", "Aguacate"], items: [{ name: "Banano", category: "Frutas", quantity: "1 unidad" }, { name: "Aguacate", category: "Frutas", quantity: "½ unidad" }], tags: ["rápido", "sin cocción"], image: image("bowl-avena_e5557c47.jpg"), description: "Una mezcla rápida de dos frutas suaves y energéticas.", preparation: "Machaca el banano y el aguacate justo antes de servir. Ajusta con agua si lo necesitas." },
  { id: "pure-zanahoria-arroz", title: "Puré de zanahoria y arroz", stage: "6 a 8 meses", meals: ["almuerzo", "cena"], method: ["Triturado", "Combinado"], minutes: 22, texture: "Suave y espeso", ingredients: ["Zanahoria", "Arroz", "Aceite de oliva"], items: [{ name: "Zanahoria", category: "Verduras", quantity: "2 unidades" }, { name: "Arroz", category: "Cereales y otros", quantity: "½ taza" }], tags: ["base suave", "vegetariano"], image: image("bowl-arroz_7a3869cb.jpg"), description: "Una base vegetal sencilla para introducir variedad de cereales.", preparation: "Cocina arroz y zanahoria hasta que estén muy tiernos. Tritura y añade unas gotas de aceite." },
  { id: "calabaza-pollo", title: "Calabaza suave con pollo", stage: "6 a 8 meses", meals: ["almuerzo", "cena"], method: ["Triturado", "Combinado"], minutes: 25, texture: "Húmeda y aterciopelada", ingredients: ["Calabaza", "Pollo", "Zanahoria"], items: [{ name: "Calabaza", category: "Verduras", quantity: "2 tazas" }, { name: "Pollo", category: "Proteínas", quantity: "150 g" }, { name: "Zanahoria", category: "Verduras", quantity: "1 unidad" }], tags: ["hierro", "suave"], image: image("bowl-pollo_d8f93e4e.jpg"), description: "Calabaza y pollo en una combinación cálida y fácil de ajustar.", preparation: "Cocina todo hasta que esté tierno. Tritura fino o deja pequeños grumos según la etapa." },
  { id: "papa-brocoli", title: "Papa cremosa con brócoli", stage: "6 a 8 meses", meals: ["almuerzo", "cena"], method: ["Triturado", "Combinado"], minutes: 20, texture: "Cremosa", ingredients: ["Papa", "Brócoli", "Aceite de oliva"], items: [{ name: "Papa", category: "Verduras", quantity: "2 unidades" }, { name: "Brócoli", category: "Verduras", quantity: "1 cabeza pequeña" }], tags: ["vegetariano", "cremosa"], image: image("bowl-lentejas_403fa9bb.jpg"), description: "Una crema verde y suave para sumar verduras sin complicar.", preparation: "Cocina papa y brócoli al vapor. Tritura con un poco del agua de cocción." },
  { id: "huevo-calabaza", title: "Huevo revuelto con calabaza", stage: "9 a 12 meses", meals: ["desayuno", "almuerzo"], method: ["BLW", "Combinado"], minutes: 15, texture: "Blanda", ingredients: ["Huevo", "Calabaza"], items: [{ name: "Huevo", category: "Proteínas", quantity: "2 unidades" }, { name: "Calabaza", category: "Verduras", quantity: "1 taza" }], tags: ["rápido", "proteína"], image: image("bowl-huevo_c7d6d2e0.jpg"), description: "Huevo completamente cocido con calabaza tierna para una comida rápida.", preparation: "Cocina la calabaza hasta ablandar. Añade el huevo batido y cocina completamente." },
  { id: "cuscus-verduras", title: "Cuscús con verduras tiernas", stage: "9 a 12 meses", meals: ["almuerzo", "cena"], method: ["BLW", "Combinado"], minutes: 18, texture: "Húmeda", ingredients: ["Cuscús", "Zanahoria", "Calabacín"], items: [{ name: "Cuscús", category: "Cereales y otros", quantity: "1 taza" }, { name: "Zanahoria", category: "Verduras", quantity: "1 unidad" }, { name: "Calabacín", category: "Verduras", quantity: "1 unidad" }], tags: ["familiar", "variedad"], image: image("blw-pasta_ae5e2591.jpg"), description: "Cuscús hidratado con verduras blandas y fáciles de comer.", preparation: "Hidrata el cuscús. Cocina las verduras hasta ablandar y mézclalas en trozos pequeños." },
  { id: "pasta-calabaza", title: "Pasta corta con crema de calabaza", stage: "9 a 12 meses", meals: ["almuerzo", "cena"], method: ["BLW", "Combinado"], minutes: 25, texture: "Muy blanda", ingredients: ["Pasta", "Calabaza", "Aceite de oliva"], items: [{ name: "Pasta", category: "Cereales y otros", quantity: "1 taza" }, { name: "Calabaza", category: "Verduras", quantity: "1 taza" }], tags: ["familiar", "sin lácteos"], image: image("blw-pasta_ae5e2591.jpg"), description: "Pasta con una salsa natural de calabaza, sin salsas preparadas.", preparation: "Cocina la pasta muy blanda. Tritura calabaza cocida y mezcla hasta cubrir." },
  { id: "arroz-lentejas", title: "Arroz meloso con lentejas", stage: "9 a 12 meses", meals: ["almuerzo", "cena"], method: ["Triturado", "Combinado"], minutes: 30, texture: "Melosa", ingredients: ["Arroz", "Lentejas", "Zanahoria"], items: [{ name: "Arroz", category: "Cereales y otros", quantity: "½ taza" }, { name: "Lentejas", category: "Proteínas", quantity: "1 taza" }, { name: "Zanahoria", category: "Verduras", quantity: "1 unidad" }], tags: ["hierro", "sin carne"], image: image("bowl-lentejas_403fa9bb.jpg"), description: "Arroz y lentejas muy tiernos para una comida completa y rendidora.", preparation: "Cocina todos los ingredientes hasta que se deshagan ligeramente. Aplasta antes de servir." },
  { id: "tortilla-verduras", title: "Tortilla suave de verduras", stage: "12 meses o más", meals: ["desayuno", "almuerzo"], method: ["BLW", "Combinado"], minutes: 18, texture: "Blanda", ingredients: ["Huevo", "Calabacín", "Zanahoria"], items: [{ name: "Huevo", category: "Proteínas", quantity: "2 unidades" }, { name: "Calabacín", category: "Verduras", quantity: "½ unidad" }, { name: "Zanahoria", category: "Verduras", quantity: "½ unidad" }], tags: ["BLW", "rápido"], image: image("bowl-huevo_c7d6d2e0.jpg"), description: "Tortilla cocida por completo con verduras ralladas y blandas.", preparation: "Ralla las verduras, cocina unos minutos y añade el huevo. Cocina a fuego bajo por ambos lados." },
  { id: "quinoa-pollo", title: "Quinua con pollo y verduras", stage: "12 meses o más", meals: ["almuerzo", "cena"], method: ["BLW", "Triturado", "Combinado"], minutes: 30, texture: "Húmeda", ingredients: ["Quinua", "Pollo", "Calabacín"], items: [{ name: "Quinua", category: "Cereales y otros", quantity: "1 taza" }, { name: "Pollo", category: "Proteínas", quantity: "180 g" }, { name: "Calabacín", category: "Verduras", quantity: "1 unidad" }], tags: ["hierro", "completa"], image: image("bowl-quinoa_b1e81455.jpg"), description: "Quinua, pollo y calabacín para una comida completa con textura húmeda.", preparation: "Cocina la quinua y el pollo por separado. Mezcla con calabacín muy tierno y ajusta la textura." },
  { id: "garbanzo-arroz", title: "Garbanzos suaves con arroz", stage: "12 meses o más", meals: ["almuerzo", "cena"], method: ["Triturado", "Combinado"], minutes: 30, texture: "Espesa", ingredients: ["Garbanzos", "Arroz", "Tomate"], items: [{ name: "Garbanzos", category: "Proteínas", quantity: "1 taza" }, { name: "Arroz", category: "Cereales y otros", quantity: "½ taza" }, { name: "Tomate", category: "Verduras", quantity: "1 unidad" }], tags: ["sin carne", "familiar"], image: image("bowl-lentejas_403fa9bb.jpg"), description: "Garbanzos cocidos con arroz y tomate suave, sin sal añadida.", preparation: "Cocina hasta que todo esté muy tierno. Tritura o aplasta los garbanzos antes de servir." },
  { id: "manzana-avena", title: "Manzana tibia con avena", stage: "9 a 12 meses", meals: ["desayuno"], method: ["Triturado", "Combinado"], minutes: 12, texture: "Cremosa", ingredients: ["Manzana", "Avena"], items: [{ name: "Manzana", category: "Frutas", quantity: "2 unidades" }, { name: "Avena", category: "Cereales y otros", quantity: "½ taza" }], tags: ["sin azúcar", "desayuno"], image: image("bowl-fruta_7845bc7e.jpg"), description: "Desayuno tibio de fruta cocida y avena, sin azúcar añadida.", preparation: "Cocina la manzana en cubos con la avena y agua hasta ablandar. Aplasta ligeramente." },
  { id: "pera-quinua", title: "Quinua dulce con pera", stage: "12 meses o más", meals: ["desayuno"], method: ["Triturado", "Combinado"], minutes: 20, texture: "Suave", ingredients: ["Quinua", "Pera"], items: [{ name: "Quinua", category: "Cereales y otros", quantity: "½ taza" }, { name: "Pera", category: "Frutas", quantity: "1 unidad" }], tags: ["desayuno", "variedad"], image: image("bowl-fruta_7845bc7e.jpg"), description: "Una forma diferente de servir quinua en la primera comida del día.", preparation: "Cocina la quinua hasta que esté suave. Añade pera cocida y aplasta según necesidad." },
  { id: "brocoli-huevo", title: "Brócoli con huevo y arroz", stage: "12 meses o más", meals: ["almuerzo", "cena"], method: ["BLW", "Combinado"], minutes: 22, texture: "Blanda", ingredients: ["Brócoli", "Huevo", "Arroz"], items: [{ name: "Brócoli", category: "Verduras", quantity: "1 cabeza pequeña" }, { name: "Huevo", category: "Proteínas", quantity: "1 unidad" }, { name: "Arroz", category: "Cereales y otros", quantity: "½ taza" }], tags: ["completa", "familiar"], image: image("bowl-arroz_7a3869cb.jpg"), description: "Arroz húmedo con brócoli y huevo completamente cocido.", preparation: "Cocina arroz y brócoli. Añade huevo revuelto bien cocido y mezcla en porciones blandas." },
  { id: "pasta-pavo", title: "Pasta suave con pavo", stage: "12 meses o más", meals: ["almuerzo", "cena"], method: ["BLW", "Combinado"], minutes: 25, texture: "Blanda", ingredients: ["Pasta", "Pavo", "Calabacín"], items: [{ name: "Pasta", category: "Cereales y otros", quantity: "1 taza" }, { name: "Pavo", category: "Proteínas", quantity: "180 g" }, { name: "Calabacín", category: "Verduras", quantity: "1 unidad" }], tags: ["hierro", "familiar"], image: image("blw-pasta_ae5e2591.jpg"), description: "Pasta muy blanda con pavo y calabacín, ideal para variar proteínas.", preparation: "Cocina la pasta y el pavo completamente. Mezcla con calabacín tierno en trozos pequeños." },
  { id: "camote-huevo", title: "Camote asado con huevo", stage: "12 meses o más", meals: ["desayuno", "almuerzo"], method: ["BLW", "Combinado"], minutes: 25, texture: "Tierno", ingredients: ["Camote", "Huevo", "Aguacate"], items: [{ name: "Camote", category: "Verduras", quantity: "1 unidad" }, { name: "Huevo", category: "Proteínas", quantity: "1 unidad" }, { name: "Aguacate", category: "Frutas", quantity: "½ unidad" }], tags: ["BLW", "completa"], image: image("bowl-lentejas_403fa9bb.jpg"), description: "Camote tierno con huevo y aguacate para comer con las manos o aplastado.", preparation: "Hornea o cocina el camote hasta ablandar. Sirve con huevo completamente cocido y aguacate." },
];

const babyVarietyRecipes: Recipe[] = [
  { id: "papaya-avena", title: "Papaya suave con avena", stage: "6 a 8 meses", meals: ["desayuno"], method: ["Triturado", "Combinado"], minutes: 10, texture: "Sedosa", ingredients: ["Papaya", "Avena"], items: [{ name: "Papaya", category: "Frutas", quantity: "1 taza" }, { name: "Avena", category: "Cereales y otros", quantity: "¼ taza" }], tags: ["fruta", "suave"], image: image("bowl-avena_e5557c47.jpg"), description: "Papaya madura y avena cocida para cambiar la rutina del desayuno.", preparation: "Cocina la avena hasta ablandar y mezcla con papaya madura triturada." },
  { id: "melocoton-arroz", title: "Melocotón con arroz suave", stage: "6 a 8 meses", meals: ["desayuno"], method: ["Triturado", "Combinado"], minutes: 14, texture: "Cremosa", ingredients: ["Melocotón", "Arroz"], items: [{ name: "Melocotón", category: "Frutas", quantity: "1 unidad" }, { name: "Arroz", category: "Cereales y otros", quantity: "¼ taza" }], tags: ["sin azúcar", "fruta"], image: image("bowl-fruta_7845bc7e.jpg"), description: "Fruta cocida con arroz para una textura suave y diferente.", preparation: "Cocina el arroz y el melocotón hasta que estén tiernos. Tritura al gusto." },
  { id: "mango-avena", title: "Mango maduro con avena", stage: "6 a 8 meses", meals: ["desayuno"], method: ["Triturado", "Combinado"], minutes: 10, texture: "Cremosa", ingredients: ["Mango", "Avena"], items: [{ name: "Mango", category: "Frutas", quantity: "1 taza" }, { name: "Avena", category: "Cereales y otros", quantity: "¼ taza" }], tags: ["rápido", "sin azúcar"], image: image("bowl-avena_e5557c47.jpg"), description: "Mango maduro con avena para una opción fresca y sencilla.", preparation: "Cocina la avena y deja templar. Mezcla con mango maduro triturado." },
  { id: "pavo-calabacin", title: "Pavo con calabacín tierno", stage: "6 a 8 meses", meals: ["almuerzo", "cena"], method: ["Triturado", "Combinado"], minutes: 25, texture: "Blanda", ingredients: ["Pavo", "Calabacín", "Papa"], items: [{ name: "Pavo", category: "Proteínas", quantity: "150 g" }, { name: "Calabacín", category: "Verduras", quantity: "1 unidad" }, { name: "Papa", category: "Verduras", quantity: "1 unidad" }], tags: ["hierro", "suave"], image: image("bowl-pollo_d8f93e4e.jpg"), description: "Pavo con dos verduras blandas para variar la proteína de la semana.", preparation: "Cocina todo completamente y tritura con un poco de agua de cocción." },
  { id: "pescado-camote", title: "Pescado blanco con camote", stage: "6 a 8 meses", meals: ["almuerzo", "cena"], method: ["Triturado", "Combinado"], minutes: 28, texture: "Húmeda", ingredients: ["Pescado blanco", "Camote", "Zanahoria"], items: [{ name: "Pescado blanco", category: "Proteínas", quantity: "150 g" }, { name: "Camote", category: "Verduras", quantity: "1 unidad" }, { name: "Zanahoria", category: "Verduras", quantity: "1 unidad" }], tags: ["variedad", "suave"], image: image("bowl-lentejas_403fa9bb.jpg"), description: "Pescado blanco bien cocido con camote para una comida suave.", preparation: "Cocina el pescado sin espinas junto con las verduras. Tritura y revisa con cuidado." },
  { id: "arroz-calabaza", title: "Arroz cremoso con calabaza", stage: "6 a 8 meses", meals: ["almuerzo", "cena"], method: ["Triturado", "Combinado"], minutes: 24, texture: "Cremosa", ingredients: ["Arroz", "Calabaza", "Calabacín"], items: [{ name: "Arroz", category: "Cereales y otros", quantity: "½ taza" }, { name: "Calabaza", category: "Verduras", quantity: "1 taza" }, { name: "Calabacín", category: "Verduras", quantity: "½ unidad" }], tags: ["vegetariano", "suave"], image: image("bowl-arroz_7a3869cb.jpg"), description: "Arroz cocido con dos verduras para una base cremosa y versátil.", preparation: "Cocina el arroz y las verduras hasta que se deshagan. Tritura o aplasta." },
];

const makeRecipe = (id: string, title: string, stage: Stage, meals: MealKey[], method: Method[], minutes: number, texture: string, ingredients: string[], items: { name: string; category: Category; quantity: string }[] | string[], tags: string[] | string, imageName: string, description: string): Recipe => {
  const normalizedItems = items.length && typeof items[0] === "string" ? (ingredients as string[]).map(name => ({ name, category: "Cereales y otros" as Category, quantity: "1 porción" })) : items as { name: string; category: Category; quantity: string }[];
  const normalizedTags = Array.isArray(tags) ? tags : tags.split(",");
  return { id, title, stage, meals, method, minutes, texture, ingredients, items: normalizedItems, tags: normalizedTags, image: image(imageName), description, preparation: `Cocina todos los ingredientes hasta que estén completamente tiernos. Sirve en la textura indicada para ${stage}.`, yield: 2 };
};

const extraRecipes: Recipe[] = [
  makeRecipe("blw-batata", "Bastones de batata y aguacate", "9 a 12 meses", ["almuerzo", "cena"], ["BLW", "Combinado"], 25, "Blanda en tiras", ["Camote", "Aguacate"], [{ name: "Camote", category: "Verduras", quantity: "1 unidad" }, { name: "Aguacate", category: "Frutas", quantity: "½ unidad" }], ["BLW", "sin cubiertos"], "blw-verduras_06099e7e.jpg", "Bastones blandos para explorar con las manos."),
  makeRecipe("blw-brocoli", "Brócoli y zanahoria en ramilletes", "9 a 12 meses", ["almuerzo", "cena"], ["BLW", "Combinado"], 18, "Muy blanda", ["Brócoli", "Zanahoria"], [{ name: "Brócoli", category: "Verduras", quantity: "1 cabeza pequeña" }, { name: "Zanahoria", category: "Verduras", quantity: "2 unidades" }], ["BLW", "vegetariano"], "blw-verduras_06099e7e.jpg", "Verduras grandes y blandas para agarrar con seguridad."),
  makeRecipe("blw-pasta-calabaza", "Pasta con calabaza en tiras", "9 a 12 meses", ["almuerzo", "cena"], ["BLW", "Combinado"], 22, "Blanda en tiras", ["Pasta", "Calabaza"], [{ name: "Pasta", category: "Cereales y otros", quantity: "1 taza" }, { name: "Calabaza", category: "Verduras", quantity: "1 taza" }], ["BLW", "familiar"], "blw-pasta_ae5e2591.jpg", "Pasta muy blanda con salsa natural de calabaza."),
  makeRecipe("blw-pancakes-pera", "Tortitas de pera y avena", "9 a 12 meses", ["desayuno"], ["BLW", "Combinado"], 18, "Blanda en tiras", ["Pera", "Avena", "Huevo"], [{ name: "Pera", category: "Frutas", quantity: "1 unidad" }, { name: "Avena", category: "Cereales y otros", quantity: "½ taza" }, { name: "Huevo", category: "Proteínas", quantity: "1 unidad" }], ["BLW", "desayuno"], "blw-pancakes_efbbb384.jpg", "Tiras blandas para un desayuno que se puede tomar con las manos."),
  makeRecipe("blw-pollo-brocoli", "Tiras de pollo con brócoli", "12 meses o más", ["almuerzo", "cena"], ["BLW", "Combinado"], 28, "Blanda en tiras", ["Pollo", "Brócoli"], [{ name: "Pollo", category: "Proteínas", quantity: "180 g" }, { name: "Brócoli", category: "Verduras", quantity: "1 cabeza pequeña" }], ["BLW", "hierro"], "blw-verduras_06099e7e.jpg", "Pollo muy tierno en tiras gruesas acompañado de brócoli."),
  makeRecipe("blw-papa-pescado", "Papa y pescado en porciones blandas", "12 meses o más", ["almuerzo", "cena"], ["BLW", "Combinado"], 28, "Blanda en porciones", ["Papa", "Pescado blanco"], [{ name: "Papa", category: "Verduras", quantity: "2 unidades" }, { name: "Pescado blanco", category: "Proteínas", quantity: "150 g" }], ["BLW", "variedad"], "blw-verduras_06099e7e.jpg", "Pescado sin espinas y papa tierna para explorar texturas."),
  makeRecipe("blw-quinua-croquetas", "Croquetas blandas de quinua", "12 meses o más", ["almuerzo"], ["BLW", "Combinado"], 30, "Blanda en piezas", ["Quinua", "Zanahoria", "Huevo"], [{ name: "Quinua", category: "Cereales y otros", quantity: "1 taza" }, { name: "Zanahoria", category: "Verduras", quantity: "1 unidad" }, { name: "Huevo", category: "Proteínas", quantity: "1 unidad" }], ["BLW", "sin carne"], "blw-pancakes_efbbb384.jpg", "Pequeñas croquetas suaves, completamente cocidas y fáciles de tomar."),
  makeRecipe("blw-mango-banano", "Mango y banano en tiras", "9 a 12 meses", ["desayuno"], ["BLW", "Combinado"], 5, "Blanda en tiras", ["Mango", "Banano"], [{ name: "Mango", category: "Frutas", quantity: "1 unidad" }, { name: "Banano", category: "Frutas", quantity: "1 unidad" }], ["BLW", "sin cocción"], "bowl-fruta_7845bc7e.jpg", "Frutas maduras cortadas en tamaños fáciles de agarrar."),
  makeRecipe("blw-calabacin", "Calabacín y zanahoria asados", "9 a 12 meses", ["almuerzo", "cena"], ["BLW", "Combinado"], 25, "Blanda en bastones", ["Calabacín", "Zanahoria"], [{ name: "Calabacín", category: "Verduras", quantity: "1 unidad" }, { name: "Zanahoria", category: "Verduras", quantity: "2 unidades" }], ["BLW", "vegetariano"], "blw-verduras_06099e7e.jpg", "Bastones de verduras asadas hasta quedar muy blandos."),
  makeRecipe("blw-arroz-brocoli", "Bolitas blandas de arroz y brócoli", "12 meses o más", ["almuerzo"], ["BLW", "Combinado"], 25, "Blanda en piezas", ["Arroz", "Brócoli", "Huevo"], [{ name: "Arroz", category: "Cereales y otros", quantity: "1 taza" }, { name: "Brócoli", category: "Verduras", quantity: "½ cabeza" }, { name: "Huevo", category: "Proteínas", quantity: "1 unidad" }], ["BLW", "familiar"], "blw-pancakes_efbbb384.jpg", "Bolitas suaves para agarrar con los dedos, sin sal añadida."),
  makeRecipe("pure-manzana-melocoton", "Puré de manzana y melocotón", "6 a 8 meses", ["desayuno"], ["Triturado", "Combinado"], 15, "Cremosa", ["Manzana", "Melocotón"], [{ name: "Manzana", category: "Frutas", quantity: "1 unidad" }, { name: "Melocotón", category: "Frutas", quantity: "1 unidad" }], ["sin azúcar", "fruta"], "bowl-fruta_7845bc7e.jpg", "Fruta cocida y triturada para una opción suave."),
  makeRecipe("pure-papa-calabacin", "Puré de papa y calabacín", "6 a 8 meses", ["almuerzo", "cena"], ["Triturado", "Combinado"], 20, "Cremosa", ["Papa", "Calabacín"], [{ name: "Papa", category: "Verduras", quantity: "1 unidad" }, { name: "Calabacín", category: "Verduras", quantity: "1 unidad" }], ["vegetariano", "suave"], "bowl-lentejas_403fa9bb.jpg", "Puré de dos verduras suaves y fáciles de preparar."),
  makeRecipe("pure-pavo-camote", "Puré de pavo y camote", "6 a 8 meses", ["almuerzo", "cena"], ["Triturado", "Combinado"], 28, "Espesa y suave", ["Pavo", "Camote"], [{ name: "Pavo", category: "Proteínas", quantity: "150 g" }, { name: "Camote", category: "Verduras", quantity: "1 unidad" }], ["hierro", "suave"], "bowl-pollo_d8f93e4e.jpg", "Pavo y camote hasta quedar muy tiernos y fáciles de ajustar."),
  makeRecipe("pure-arvejas-papa", "Crema de arvejas y papa", "6 a 8 meses", ["almuerzo", "cena"], ["Triturado", "Combinado"], 22, "Cremosa", ["Arvejas", "Papa"], [{ name: "Arvejas", category: "Verduras", quantity: "1 taza" }, { name: "Papa", category: "Verduras", quantity: "1 unidad" }], ["vegetariano", "verde"], "bowl-lentejas_403fa9bb.jpg", "Una crema verde y suave para variar las verduras."),
  makeRecipe("pure-pollo-arroz", "Pollo con arroz y calabaza", "6 a 8 meses", ["almuerzo", "cena"], ["Triturado", "Combinado"], 27, "Húmeda y suave", ["Pollo", "Arroz", "Calabaza"], [{ name: "Pollo", category: "Proteínas", quantity: "150 g" }, { name: "Arroz", category: "Cereales y otros", quantity: "½ taza" }, { name: "Calabaza", category: "Verduras", quantity: "1 taza" }], ["hierro", "completa"], "bowl-pollo_d8f93e4e.jpg", "Una combinación completa para variar el almuerzo."),
  makeRecipe("pasta-brocoli", "Pasta con brócoli y aceite de oliva", "12 meses o más", ["almuerzo", "cena"], ["BLW", "Combinado"], 22, "Blanda", ["Pasta", "Brócoli"], [{ name: "Pasta", category: "Cereales y otros", quantity: "1 taza" }, { name: "Brócoli", category: "Verduras", quantity: "1 cabeza pequeña" }], ["familiar", "vegetariano"], "blw-pasta_ae5e2591.jpg", "Pasta muy blanda con brócoli tierno para comer con las manos."),
  makeRecipe("pasta-pollo-calabaza", "Pasta con pollo y calabaza", "12 meses o más", ["almuerzo", "cena"], ["BLW", "Combinado"], 28, "Blanda", ["Pasta", "Pollo", "Calabaza"], [{ name: "Pasta", category: "Cereales y otros", quantity: "1 taza" }, { name: "Pollo", category: "Proteínas", quantity: "150 g" }, { name: "Calabaza", category: "Verduras", quantity: "1 taza" }], ["hierro", "familiar"], "blw-pasta_ae5e2591.jpg", "Pasta blanda con pollo completamente cocido y calabaza."),
  makeRecipe("tortita-calabacin", "Tortitas de calabacín y avena", "12 meses o más", ["desayuno", "almuerzo"], ["BLW", "Combinado"], 20, "Blanda en tiras", ["Calabacín", "Avena", "Huevo"], [{ name: "Calabacín", category: "Verduras", quantity: "1 unidad" }, { name: "Avena", category: "Cereales y otros", quantity: "½ taza" }, { name: "Huevo", category: "Proteínas", quantity: "1 unidad" }], ["BLW", "vegetariano"], "blw-pancakes_efbbb384.jpg", "Tortitas blandas de verduras, cocidas por completo."),
  makeRecipe("tortita-camote", "Tortitas de camote y quinua", "12 meses o más", ["desayuno"], ["BLW", "Combinado"], 25, "Blanda en tiras", ["Camote", "Quinua", "Huevo"], [{ name: "Camote", category: "Verduras", quantity: "1 unidad" }, { name: "Quinua", category: "Cereales y otros", quantity: "½ taza" }, { name: "Huevo", category: "Proteínas", quantity: "1 unidad" }], ["BLW", "sin azúcar"], "blw-pancakes_efbbb384.jpg", "Tortitas suaves con camote y quinua para variar el desayuno."),
  makeRecipe("quinoa-verduras-verdes", "Quinua con brócoli y arvejas", "12 meses o más", ["almuerzo", "cena"], ["BLW", "Triturado", "Combinado"], 28, "Húmeda", ["Quinua", "Brócoli", "Arvejas"], [{ name: "Quinua", category: "Cereales y otros", quantity: "1 taza" }, { name: "Brócoli", category: "Verduras", quantity: "½ cabeza" }, { name: "Arvejas", category: "Verduras", quantity: "½ taza" }], ["sin carne", "verde"], "bowl-quinoa_b1e81455.jpg", "Quinua con verduras verdes para una comida colorida."),
  makeRecipe("arroz-pescado", "Arroz con pescado y calabacín", "12 meses o más", ["almuerzo", "cena"], ["BLW", "Combinado"], 28, "Húmeda", ["Arroz", "Pescado blanco", "Calabacín"], [{ name: "Arroz", category: "Cereales y otros", quantity: "1 taza" }, { name: "Pescado blanco", category: "Proteínas", quantity: "150 g" }, { name: "Calabacín", category: "Verduras", quantity: "1 unidad" }], ["variedad", "completa"], "bowl-arroz_7a3869cb.jpg", "Arroz húmedo con pescado sin espinas y verduras blandas."),
  makeRecipe("aguacate-garbanzos", "Aguacate con garbanzos suaves", "12 meses o más", ["almuerzo"], ["BLW", "Triturado", "Combinado"], 20, "Blanda", ["Aguacate", "Garbanzos", "Tomate"], [{ name: "Aguacate", category: "Frutas", quantity: "1 unidad" }, { name: "Garbanzos", category: "Proteínas", quantity: "1 taza" }, { name: "Tomate", category: "Verduras", quantity: "1 unidad" }], ["sin carne", "cremosa"], "bowl-huevo_c7d6d2e0.jpg", "Garbanzos muy suaves con aguacate y tomate maduro."),
];

const earlyBlwRecipes: Recipe[] = [
  makeRecipe("blw-aguacate-6m", "Aguacate en gajos blandos", "6 a 8 meses", ["desayuno"], ["BLW", "Combinado"], 5, "Blanda en gajos", ["Aguacate"], [{ name: "Aguacate", category: "Frutas", quantity: "½ unidad" }], ["BLW", "sin cocción"], "blw-verduras_06099e7e.jpg", "Gajos grandes y blandos para explorar con las manos."),
  makeRecipe("blw-batata-6m", "Batata en bastones suaves", "6 a 8 meses", ["almuerzo", "cena"], ["BLW", "Combinado"], 25, "Blanda en bastones", ["Camote"], [{ name: "Camote", category: "Verduras", quantity: "1 unidad" }], ["BLW", "vegetariano"], "blw-verduras_06099e7e.jpg", "Bastones de batata horneados hasta quedar muy blandos."),
  makeRecipe("blw-brocoli-6m", "Brócoli en ramilletes tiernos", "6 a 8 meses", ["almuerzo", "cena"], ["BLW", "Combinado"], 18, "Muy blanda", ["Brócoli"], [{ name: "Brócoli", category: "Verduras", quantity: "1 cabeza pequeña" }], ["BLW", "vegetariano"], "blw-verduras_06099e7e.jpg", "Ramilletes grandes y tiernos con tallo para agarrar."),
  makeRecipe("blw-pancake-6m", "Tiras de tortita de banano", "6 a 8 meses", ["desayuno"], ["BLW", "Combinado"], 18, "Blanda en tiras", ["Banano", "Avena", "Huevo"], [{ name: "Banano", category: "Frutas", quantity: "1 unidad" }, { name: "Avena", category: "Cereales y otros", quantity: "½ taza" }, { name: "Huevo", category: "Proteínas", quantity: "1 unidad" }], ["BLW", "desayuno"], "blw-pancakes_efbbb384.jpg", "Tiras blandas de tortita, sin azúcar ni sal añadida."),
];

const expandedRecipes: Recipe[] = [
  makeRecipe("desayuno-mijo-banano", "Mijo cremoso con banano", "6 a 8 meses", ["desayuno"], ["Triturado","Combinado"], 12, "Cremosa", ["Mijo","Banano"], ["sin azúcar","desayuno"], "sin azúcar,desayuno", "bowl-avena_e5557c47.jpg", "Mijo cocido con banano maduro para un desayuno suave."),
  makeRecipe("desayuno-papaya-platano", "Papaya y plátano suaves", "6 a 8 meses", ["desayuno"], ["Triturado","Combinado"], 5, "Sedosa", ["Papaya","Banano"], ["fruta","rápido"], "fruta,rápido", "bowl-fruta_7845bc7e.jpg", "Frutas maduras combinadas para una opción rápida y fresca."),
  makeRecipe("desayuno-pera-mijo", "Pera tibia con mijo", "6 a 8 meses", ["desayuno"], ["Triturado","Combinado"], 18, "Suave", ["Pera","Mijo"], ["sin azúcar","desayuno"], "sin azúcar,desayuno", "bowl-fruta_7845bc7e.jpg", "Pera cocida con mijo hasta lograr una textura suave."),
  makeRecipe("almuerzo-pavo-calabaza", "Pavo con calabaza y arroz", "6 a 8 meses", ["almuerzo"], ["Triturado","Combinado"], 28, "Húmeda", ["Pavo","Calabaza","Arroz"], ["hierro","completa"], "hierro,completa", "bowl-pollo_d8f93e4e.jpg", "Pavo, arroz y calabaza para una comida completa."),
  makeRecipe("almuerzo-lenteja-camote", "Lentejas con camote suave", "6 a 8 meses", ["almuerzo"], ["Triturado","Combinado"], 30, "Espesa", ["Lentejas","Camote"], ["hierro","sin carne"], "hierro,sin carne", "bowl-lentejas_403fa9bb.jpg", "Lentejas y camote cocidos hasta quedar muy tiernos."),
  makeRecipe("almuerzo-pollo-arvejas", "Pollo con arvejas y papa", "6 a 8 meses", ["almuerzo"], ["Triturado","Combinado"], 27, "Cremosa", ["Pollo","Arvejas","Papa"], ["hierro","verde"], "hierro,verde", "bowl-pollo_d8f93e4e.jpg", "Pollo con verduras verdes y papa para una textura cremosa."),
  makeRecipe("cena-pescado-arroz", "Pescado blanco con arroz y calabacín", "6 a 8 meses", ["cena"], ["Triturado","Combinado"], 25, "Húmeda", ["Pescado blanco","Arroz","Calabacín"], ["variedad","suave"], "variedad,suave", "bowl-arroz_7a3869cb.jpg", "Pescado sin espinas con arroz y calabacín muy tierno."),
  makeRecipe("cena-pollo-yuca", "Pollo con yuca y zanahoria", "6 a 8 meses", ["cena"], ["Triturado","Combinado"], 30, "Espesa", ["Pollo","Yuca","Zanahoria"], ["hierro","suave"], "hierro,suave", "bowl-pollo_d8f93e4e.jpg", "Yuca, zanahoria y pollo cocidos hasta deshacerse."),
  makeRecipe("cena-huevo-calabaza", "Huevo con calabaza y avena", "6 a 8 meses", ["cena"], ["Triturado","Combinado"], 20, "Cremosa", ["Huevo","Calabaza","Avena"], ["proteína","suave"], "proteína,suave", "bowl-arroz_7a3869cb.jpg", "Una mezcla suave de huevo bien cocido, calabaza y avena."),
  makeRecipe("desayuno-tortita-manzana", "Tortita blanda de manzana", "9 a 12 meses", ["desayuno"], ["BLW","Combinado"], 18, "Blanda en tiras", ["Manzana","Avena","Huevo"], ["BLW","sin azúcar"], "BLW,sin azúcar", "blw-pancakes_efbbb384.jpg", "Tiras blandas de manzana, avena y huevo completamente cocidas."),
  makeRecipe("desayuno-yogur-mango", "Yogur natural con mango y avena", "9 a 12 meses", ["desayuno"], ["Triturado","Combinado"], 5, "Cremosa", ["Yogur natural","Mango","Avena"], ["rápido","fruta"], "rápido,fruta", "bowl-fruta_7845bc7e.jpg", "Yogur natural sin azúcar con mango maduro y avena suave."),
  makeRecipe("desayuno-arepa-aguacate", "Arepita blanda con aguacate", "9 a 12 meses", ["desayuno"], ["BLW","Combinado"], 20, "Blanda en piezas", ["Arepa","Aguacate"], ["BLW","energía"], "BLW,energía", "blw-pancakes_efbbb384.jpg", "Arepita blanda en tiras con aguacate maduro."),
  makeRecipe("almuerzo-arroz-pavo", "Arroz con pavo y brócoli", "9 a 12 meses", ["almuerzo"], ["BLW","Combinado"], 25, "Blanda", ["Arroz","Pavo","Brócoli"], ["hierro","familiar"], "hierro,familiar", "bowl-arroz_7a3869cb.jpg", "Arroz húmedo con pavo deshebrado y brócoli tierno."),
  makeRecipe("almuerzo-pasta-lentejas", "Pasta con salsa de lentejas", "9 a 12 meses", ["almuerzo"], ["Triturado","Combinado"], 30, "Muy blanda", ["Pasta","Lentejas","Zanahoria"], ["sin carne","familiar"], "sin carne,familiar", "blw-pasta_ae5e2591.jpg", "Pasta muy blanda con una salsa espesa de lentejas y zanahoria."),
  makeRecipe("almuerzo-cuscus-verduras", "Cuscús suave con verduras", "9 a 12 meses", ["almuerzo"], ["Triturado","Combinado"], 15, "Húmeda", ["Cuscús","Calabacín","Zanahoria"], ["vegetariano","rápido"], "vegetariano,rápido", "bowl-arroz_7a3869cb.jpg", "Cuscús hidratado con verduras muy tiernas."),
  makeRecipe("almuerzo-pescado-papa", "Pescado con papa y brócoli", "9 a 12 meses", ["almuerzo"], ["BLW","Combinado"], 25, "Blanda en piezas", ["Pescado blanco","Papa","Brócoli"], ["BLW","variedad"], "BLW,variedad", "blw-verduras_06099e7e.jpg", "Porciones blandas de pescado, papa y brócoli sin espinas."),
  makeRecipe("cena-quinoa-verduras", "Quinua con verduras y huevo", "9 a 12 meses", ["cena"], ["Triturado","Combinado"], 25, "Húmeda", ["Quinua","Huevo","Calabacín"], ["sin carne","completa"], "sin carne,completa", "bowl-quinoa_b1e81455.jpg", "Quinua húmeda con verduras y huevo completamente cocido."),
  makeRecipe("cena-albondigas-pavo", "Albóndigas blandas de pavo", "9 a 12 meses", ["cena"], ["BLW","Combinado"], 30, "Blanda en piezas", ["Pavo","Avena","Zanahoria"], ["BLW","hierro"], "BLW,hierro", "blw-pancakes_efbbb384.jpg", "Albóndigas blandas de pavo y avena, sin sal añadida."),
  makeRecipe("cena-camote-frijol", "Camote con frijoles suaves", "9 a 12 meses", ["cena"], ["Triturado","Combinado"], 30, "Cremosa", ["Camote","Frijoles","Tomate"], ["sin carne","completa"], "sin carne,completa", "bowl-lentejas_403fa9bb.jpg", "Frijoles muy suaves con camote y tomate cocido."),
  makeRecipe("desayuno-waffle-banano", "Waffle blando de banano y avena", "12 meses o más", ["desayuno"], ["BLW","Combinado"], 20, "Blanda en tiras", ["Banano","Avena","Huevo"], ["BLW","sin azúcar"], "BLW,sin azúcar", "blw-pancakes_efbbb384.jpg", "Waffle blando en tiras, sin azúcar añadida."),
  makeRecipe("desayuno-huevo-tomate", "Huevo revuelto con tomate y arepa", "12 meses o más", ["desayuno"], ["BLW","Combinado"], 15, "Blanda", ["Huevo","Tomate","Arepa"], ["familiar","proteína"], "familiar,proteína", "bowl-arroz_7a3869cb.jpg", "Huevo bien cocido con tomate y arepa blanda."),
  makeRecipe("almuerzo-curry-lentejas", "Lentejas suaves con arroz y coco", "12 meses o más", ["almuerzo"], ["Triturado","Combinado"], 30, "Cremosa", ["Lentejas","Arroz","Leche de coco"], ["sin carne","familiar"], "sin carne,familiar", "bowl-lentejas_403fa9bb.jpg", "Lentejas suaves con arroz y un toque de leche de coco."),
  makeRecipe("almuerzo-pasta-verduras", "Pasta con verduras y ricota", "12 meses o más", ["almuerzo"], ["BLW","Combinado"], 20, "Blanda", ["Pasta","Ricota","Calabacín"], ["familiar","vegetariano"], "familiar,vegetariano", "blw-pasta_ae5e2591.jpg", "Pasta muy blanda con ricota y calabacín tierno."),
  makeRecipe("almuerzo-tortilla-verduras", "Tortilla suave de verduras", "12 meses o más", ["almuerzo"], ["BLW","Combinado"], 18, "Blanda en piezas", ["Huevo","Papa","Calabacín"], ["BLW","vegetariano"], "BLW,vegetariano", "blw-pancakes_efbbb384.jpg", "Tortilla completamente cocida cortada en tiras blandas."),
  makeRecipe("cena-pollo-yuca", "Pollo deshebrado con yuca", "12 meses o más", ["cena"], ["BLW","Combinado"], 30, "Blanda en piezas", ["Pollo","Yuca","Aguacate"], ["BLW","hierro"], "BLW,hierro", "blw-verduras_06099e7e.jpg", "Pollo muy tierno con yuca y aguacate maduro."),
  makeRecipe("cena-salmon-quinoa", "Salmón con quinua y brócoli", "12 meses o más", ["cena"], ["BLW","Combinado"], 30, "Blanda", ["Salmón","Quinua","Brócoli"], ["variedad","omega 3"], "variedad,omega 3", "bowl-quinoa_b1e81455.jpg", "Salmón bien cocido con quinua y brócoli tierno."),
  makeRecipe("cena-garbanzos-pasta", "Garbanzos con pasta y verduras", "12 meses o más", ["cena"], ["Triturado","Combinado"], 30, "Espesa", ["Garbanzos","Pasta","Zanahoria"], ["sin carne","familiar"], "sin carne,familiar", "bowl-lentejas_403fa9bb.jpg", "Garbanzos cocidos con pasta y zanahoria muy suave."),
  makeRecipe("snack-banano-avena", "Bocados blandos de banano y avena", "12 meses o más", ["desayuno"], ["BLW","Combinado"], 20, "Blanda en piezas", ["Banano","Avena","Huevo"], ["BLW","sin azúcar"], "BLW,sin azúcar", "blw-pancakes_efbbb384.jpg", "Bocados blandos para desayuno o merienda."),
];

const blwRecipeIds = new Set([...extraRecipes.filter(recipe => recipe.tags.includes("BLW")).map(recipe => recipe.id), ...earlyBlwRecipes.map(recipe => recipe.id), "pasta-calabacin", "tortitas-avena", "aguacate-huevo", "arroz-verduras", "camote-garbanzos", "pasta-brocoli", "pasta-pollo-calabaza", "tortita-calabacin", "tortita-camote", "arroz-pescado"]);

const recipeCatalog: Recipe[] = [...recipes, ...moreRecipes, ...babyVarietyRecipes, ...extraRecipes, ...earlyBlwRecipes, ...expandedRecipes];


const weekDays = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
const mealLabels: Record<MealKey, string> = { desayuno: "Desayuno", almuerzo: "Almuerzo", cena: "Cena" };
const mealOrder: MealKey[] = ["desayuno", "almuerzo", "cena"];
const defaultProfile: Profile = { stage: "6 a 8 meses", method: "Combinado", avoid: [], available: [], time: "Cualquier tiempo" };
const initialWeek: WeekDay[] = weekDays.map((day, index) => ({ day, meals: { desayuno: ["avena-banano", "papilla-pera-avena", "platano-aguacate", "tortitas-avena", "manzana-avena", "pera-quinua", "huevo-calabaza"][index], almuerzo: ["verduras-pollo", "pure-zanahoria-arroz", "pasta-calabacin", "lentejas-verduras", "arroz-verduras", "quinoa-pollo", "garbanzo-arroz"][index], cena: ["manzana-pera", "calabaza-pollo", "papa-brocoli", "pasta-calabaza", "arroz-lentejas", "brocoli-huevo", "camote-huevo"][index] } }));

function readLocal<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) as T : fallback;
  } catch {
    return fallback;
  }
}

function recipeById(id: string) {
  return recipeCatalog.find(recipe => recipe.id === id) ?? recipeCatalog[0];
}

function mergeQuantity(first: string, second: string) {
  const parse = (value: string) => {
    const match = value.trim().match(/^([\d.½¼¾]+)\s*(.*)$/);
    if (!match) return null;
    const number = match[1] === "½" ? 0.5 : match[1] === "¼" ? 0.25 : match[1] === "¾" ? 0.75 : Number(match[1]);
    return { number, unit: match[2].trim() };
  };
  const left = parse(first);
  const right = parse(second);
  if (!left || !right) return first;
  const leftUnit = left.unit.toLocaleLowerCase();
  const rightUnit = right.unit.toLocaleLowerCase();
  if (leftUnit !== rightUnit) return first;
  const total = left.number + right.number;
  const formatted = total === 0.5 ? "½" : total === 0.25 ? "¼" : total === 0.75 ? "¾" : Number.isInteger(total) ? String(total) : total.toFixed(2).replace(/0+$/, "");
  return `${formatted} ${left.unit}`;
}

function normalizeIngredient(value: string) {
  return value.trim().toLocaleLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function compatible(recipe: Recipe, profile: Profile, meal?: MealKey) {
  const stageOkay = recipe.stage === profile.stage || (profile.stage === "12 meses o más" && recipe.stage !== "6 a 8 meses");
  const methodOkay = profile.method === "BLW" ? blwRecipeIds.has(recipe.id) : recipe.method.includes(profile.method);
  const mealOkay = !meal || recipe.meals.includes(meal);
  const avoidSet = new Set(profile.avoid.map(normalizeIngredient));
  const availableSet = new Set(profile.available.map(normalizeIngredient));
  const avoidOkay = !recipe.ingredients.some(item => avoidSet.has(normalizeIngredient(item)));
  const availableOkay = !profile.available.length || recipe.ingredients.some(item => availableSet.has(normalizeIngredient(item)));
  const timeOkay = profile.time === "Cualquier tiempo" || profile.time === "Más de 30 min" || (profile.time === "15 a 30 min" && recipe.minutes <= 30) || (profile.time === "Menos de 15 min" && recipe.minutes < 15);
  return stageOkay && methodOkay && mealOkay && avoidOkay && availableOkay && timeOkay;
}

function createPlan(profile: Profile): WeekDay[] {
  const used = new Set<string>();
  return weekDays.map((day, dayIndex) => {
    const meals = {} as Record<MealKey, string>;
    for (const meal of mealOrder) {
      const matching = recipeCatalog.filter(recipe => compatible(recipe, profile, meal));
      const fallback = recipeCatalog.filter(recipe => compatible(recipe, { ...profile, time: "Más de 30 min" }, meal));
      const safeFallback = recipeCatalog.filter(recipe => compatible(recipe, { ...profile, time: "Cualquier tiempo", available: [] }, meal));
      const pool = matching.length ? matching : fallback.length ? fallback : safeFallback;
      const unique = pool.filter((recipe, index) => pool.findIndex(item => item.id === recipe.id) === index);
      const unused = unique.filter(recipe => !used.has(recipe.id));
      const candidates = unused.length ? unused : unique;
      const chosen = candidates[(dayIndex + mealOrder.indexOf(meal)) % candidates.length] ?? recipeCatalog[0];
      meals[meal] = chosen.id;
      used.add(chosen.id);
    }
    return { day, meals };
  });
}

function buildShopping(plan: WeekDay[]): ShoppingItem[] {
  const merged = new Map<string, ShoppingItem>();
  plan.forEach(day => mealOrder.forEach(meal => {
    const recipe = recipeById(day.meals[meal]);
    recipe.items.forEach(item => {
      const current = merged.get(item.name);
      merged.set(item.name, current ? { ...current, quantity: mergeQuantity(current.quantity, item.quantity) } : { name: item.name, category: item.category, quantity: item.quantity, checked: false });
    });
  }));
  return Array.from(merged.values());
}

function ProgressBar({ completed, total }: { completed: number; total: number }) {
  return <div className="h-2 w-full overflow-hidden rounded-full bg-[#e5e9df]"><div className="h-full rounded-full bg-[#6d8d67] transition-all duration-300" style={{ width: `${total ? Math.round((completed / total) * 100) : 0}%` }} /></div>;
}

export default function Home() {
  const { user, isAuthenticated, logout } = useAuth();
  const stateQuery = trpc.appState.get.useQuery(undefined, { enabled: isAuthenticated });
  const saveState = trpc.appState.save.useMutation();
  const [profile, setProfile] = useState<Profile>(() => readLocal("menu-bebes-profile", defaultProfile));
  const [week, setWeek] = useState<WeekDay[]>(() => readLocal("menu-bebes-week", initialWeek));
  const [favorites, setFavorites] = useState<string[]>(() => readLocal("menu-bebes-favorites", ["avena-banano", "verduras-pollo"]));
  const [shopping, setShopping] = useState<ShoppingItem[]>(() => readLocal("menu-bebes-shopping", buildShopping(initialWeek)));
  const [activeTab, setActiveTab] = useState("inicio");
  const [search, setSearch] = useState("");
  const [mealFilter, setMealFilter] = useState<MealKey | "todos">("todos");
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [replacement, setReplacement] = useState<{ dayIndex: number; meal: MealKey; options: Recipe[] } | null>(null);
  const [customAvoid, setCustomAvoid] = useState("");
  const [customAvailable, setCustomAvailable] = useState("");
  const [showMobileNav, setShowMobileNav] = useState(false);
  const [hasHydrated, setHasHydrated] = useState(!isAuthenticated);
  const [showAllFilters, setShowAllFilters] = useState(false);
  const [weekView, setWeekView] = useState<"list" | "calendar">("list");
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showInstallHelp, setShowInstallHelp] = useState(() => /iPad|iPhone|iPod/.test(navigator.userAgent) && !(navigator as Navigator & { standalone?: boolean }).standalone);
  const lastSynced = useRef(false);

  useEffect(() => {
    const onInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as BeforeInstallPromptEvent);
    };
    window.addEventListener("beforeinstallprompt", onInstallPrompt);
    window.addEventListener("appinstalled", () => setInstallPrompt(null));
    return () => window.removeEventListener("beforeinstallprompt", onInstallPrompt);
  }, []);

  const installApp = async () => {
    if (!installPrompt) {
      setShowInstallHelp(current => !current);
      return;
    }
    await installPrompt.prompt();
    await installPrompt.userChoice;
    setInstallPrompt(null);
  };

  useEffect(() => {
    if (!isAuthenticated) {
      setHasHydrated(true);
      return;
    }
    if (stateQuery.isFetched && !lastSynced.current) {
      const state = stateQuery.data;
      if (state?.profile) setProfile(state.profile as Profile);
      if (state?.plan) setWeek(state.plan as WeekDay[]);
      if (state?.favorites) setFavorites(state.favorites as string[]);
      if (state?.shopping) setShopping(state.shopping as ShoppingItem[]);
      lastSynced.current = true;
      setHasHydrated(true);
    }
  }, [isAuthenticated, stateQuery.data, stateQuery.isFetched]);

  useEffect(() => {
    if (!hasHydrated) return;
    window.localStorage.setItem("menu-bebes-profile", JSON.stringify(profile));
    window.localStorage.setItem("menu-bebes-week", JSON.stringify(week));
    window.localStorage.setItem("menu-bebes-favorites", JSON.stringify(favorites));
    window.localStorage.setItem("menu-bebes-shopping", JSON.stringify(shopping));
    if (isAuthenticated) {
      saveState.mutate({ profile, plan: week, favorites, shopping });
    }
  }, [profile, week, favorites, shopping, hasHydrated, isAuthenticated]);

  const filteredRecipes = useMemo(() => recipeCatalog.filter(recipe => {
    const queryOkay = !search || `${recipe.title} ${recipe.ingredients.join(" ")} ${recipe.tags.join(" ")}`.toLowerCase().includes(search.toLowerCase());
    const mealOkay = mealFilter === "todos" || recipe.meals.includes(mealFilter);
    return queryOkay && mealOkay && compatible(recipe, profile);
  }), [search, mealFilter, profile]);

  const todayOptions = useMemo(() => filteredRecipes.slice(0, 6), [filteredRecipes]);
  const favoriteRecipes = recipeCatalog.filter(recipe => favorites.includes(recipe.id));
  const completedShopping = shopping.filter(item => item.checked).length;
  const planRecipeCount = week.length * mealOrder.length;

  const generateWeek = () => {
    const next = createPlan(profile);
    setWeek(next);
    setShopping(buildShopping(next));
    setActiveTab("semana");
    toast.success("Tu semana está lista", { description: "Puedes cambiar cualquier comida sin perder el resto del plan." });
  };

  const replaceMeal = (dayIndex: number, meal: MealKey) => {
    const currentId = week[dayIndex]?.meals[meal];
    const compatibleOptions = recipeCatalog.filter(recipe => compatible(recipe, profile, meal) && recipe.id !== currentId);
    const fallbackOptions = recipeCatalog.filter(recipe => compatible(recipe, { ...profile, time: "Cualquier tiempo", available: [] }, meal) && recipe.id !== currentId);
    const pool = [...compatibleOptions, ...fallbackOptions].filter((recipe, index, all) => all.findIndex(item => item.id === recipe.id) === index).slice(0, 3);
    if (pool.length) setReplacement({ dayIndex, meal, options: pool });
  };

  const chooseReplacement = (recipeId: string) => {
    if (!replacement) return;
    const nextWeek = week.map((day, index) => index === replacement.dayIndex ? { ...day, meals: { ...day.meals, [replacement.meal]: recipeId } } : day);
    setWeek(nextWeek);
    setShopping(buildShopping(nextWeek));
    setReplacement(null);
    toast.success("Comida cambiada", { description: "El resto de tu semana permanece igual." });
  };

  const toggleFavorite = (id: string) => {
    setFavorites(current => current.includes(id) ? current.filter(item => item !== id) : [...current, id]);
    toast.success(favorites.includes(id) ? "Quitada de guardados" : "Guardada para después");
  };

  const addRecipeToWeek = (recipe: Recipe) => {
    const meal = recipe.meals.find(item => mealOrder.includes(item)) ?? "almuerzo";
    const nextWeek = week.map((day, index) => index === 0 ? { ...day, meals: { ...day.meals, [meal]: recipe.id } } : day);
    setWeek(nextWeek);
    setShopping(buildShopping(nextWeek));
  };

  const toggleShopping = (name: string) => setShopping(current => current.map(item => item.name === name ? { ...item, checked: !item.checked } : item));

  const updateProfile = (key: keyof Profile, value: string | string[]) => setProfile(current => ({ ...current, [key]: value }));
  const toggleListValue = (key: "avoid" | "available", value: string) => setProfile(current => ({ ...current, [key]: current[key].includes(value) ? current[key].filter(item => item !== value) : [...current[key], value] }));
  const addCustom = (key: "avoid" | "available", value: string, clear: (value: string) => void) => { const clean = value.trim(); if (!clean) return; const exists = profile[key].some(item => normalizeIngredient(item) === normalizeIngredient(clean)); if (!exists) updateProfile(key, [...profile[key], clean]); clear(""); };

  const navItems = [
    { id: "inicio", label: "Hoy", icon: Sparkles },
    { id: "semana", label: "Mi semana", icon: CalendarDays },
    { id: "compra", label: "Mi compra", icon: ShoppingBasket },
    { id: "guardados", label: "Guardados", icon: Heart },
  ];

  const Nav = ({ mobile = false }: { mobile?: boolean }) => <nav className={mobile ? "grid gap-1" : "hidden items-center gap-1 md:flex"}>
    {navItems.map(item => {
      const Icon = item.icon;
      return <button key={item.id} onClick={() => { setActiveTab(item.id); setShowMobileNav(false); }} className={`nav-link ${activeTab === item.id ? "nav-link-active" : ""}`}><Icon size={16} />{item.label}</button>;
    })}
  </nav>;

  return (
    <div className="min-h-screen bg-[#fbfaf5] text-[#23352f]">
      <header className="sticky top-0 z-40 border-b border-[#e0e5dc] bg-[#fbfaf5]/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1180px] items-center justify-between px-4 lg:px-8">
          <button onClick={() => setActiveTab("inicio")} className="text-left" aria-label="Ir a inicio">
            <BrandLogo />
          </button>
          <div className="hidden md:block" />
          <div className="flex items-center gap-2">
            {isAuthenticated ? <div className="hidden items-center gap-2 sm:flex"><span className="text-xs font-medium text-[#6c7f74]">{user?.name ?? "Tu cuenta"}</span><button className="icon-button" title="Cerrar sesión" onClick={() => logout()}><LogOut size={16} /></button></div> : <Button onClick={() => startLogin()} variant="outline" className="hidden border-[#d8dfd3] bg-white text-xs text-[#45624d] sm:flex"><LogIn size={15} />Guardar mi progreso</Button>}
            <Sheet open={showMobileNav} onOpenChange={setShowMobileNav}><SheetTrigger asChild><Button variant="ghost" size="icon" className="md:hidden"><Menu size={20} /></Button></SheetTrigger><SheetContent side="right" className="w-[280px] bg-[#fbfaf5]"><SheetHeader><SheetTitle className="font-display text-left text-[#23352f]">Menú bebés</SheetTitle></SheetHeader><div className="mt-6"><Nav mobile /></div><Separator className="my-6" />{isAuthenticated ? <Button variant="outline" className="w-full" onClick={() => logout()}><LogOut size={15} />Cerrar sesión</Button> : <Button className="w-full bg-[#466d51]" onClick={() => startLogin()}><LogIn size={15} />Guardar mi progreso</Button>}</SheetContent></Sheet>
          </div>
        </div>
      </header>

      {(installPrompt || showInstallHelp) && <div className="border-b border-[#e0e5dc] bg-[#eef4eb] px-4 py-3"><div className="mx-auto flex max-w-[1180px] items-center justify-between gap-3 lg:px-8"><div><p className="text-sm font-semibold text-[#38523e]">Lleva Menú bebés contigo</p>{showInstallHelp && !installPrompt && <p className="mt-0.5 text-xs leading-5 text-[#6c7f74]">En iPhone: pulsa Compartir y luego “Añadir a pantalla de inicio”.</p>}</div><Button onClick={installApp} size="sm" className="shrink-0 bg-[#466d51] text-white hover:bg-[#385c42]"><Download size={15} />{installPrompt ? "Instalar app" : "Cómo instalar"}</Button></div></div>}

      <main className="mx-auto max-w-[1180px] px-4 pb-28 pt-6 lg:px-8 lg:pt-10">
        <div className="mb-8 flex flex-col justify-between gap-5 lg:flex-row lg:items-end">
          <div><div className="eyebrow"><span className="eyebrow-dot" />¿Qué le doy hoy? Resuelto.</div><h1 className="mt-3 max-w-[680px] font-display text-4xl font-semibold leading-[1.02] tracking-[-0.04em] text-[#23352f] sm:text-5xl">La comida de tu bebé, ya organizada.</h1><p className="mt-4 max-w-[620px] text-base leading-7 text-[#6c7f74]">Personaliza tu semana según la etapa de tu bebé, los alimentos que necesitas evitar y lo que tienes disponible. Recibe un menú completo, sustituciones rápidas y exactamente qué necesitas comprar.</p></div>
          <div className="flex items-center gap-3 lg:pb-1"><div className="hidden text-right sm:block"><p className="text-xs font-semibold uppercase tracking-[0.16em] text-[#9aa79b]">Tu progreso</p><p className="mt-1 text-sm font-medium text-[#47634f]">{completedShopping} de {shopping.length || 1} compras marcadas</p></div><button className="flex items-center gap-2 rounded-full border border-[#d8dfd3] bg-white px-3 py-2.5 text-xs font-semibold text-[#55745a] shadow-sm transition hover:-translate-y-0.5" onClick={() => document.getElementById("perfil-bebe")?.scrollIntoView({ behavior: "smooth", block: "center" })} title="Ver Perfil del bebé"><Baby size={18} /><span className="hidden sm:inline">Perfil del bebé</span></button></div>
        </div>

        <div className="app-grid">
          <aside className="space-y-5">
            <Card id="perfil-bebe" className="profile-card overflow-hidden border-0 shadow-[0_18px_45px_rgba(48,75,58,0.08)]"><CardHeader className="border-b border-white/50 pb-4"><div className="flex items-start justify-between"><div><p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#d7e4d2]">Perfil del bebé</p><CardTitle className="mt-1 font-display text-xl text-white">Tu punto de partida</CardTitle></div><span className="rounded-full bg-white/15 p-2 text-white"><Baby size={19} /></span></div><p className="mt-3 text-xs leading-5 text-[#d7e4d2]">Edita aquí la etapa, el método y los alimentos de tu bebé. El tiempo para cocinar lo eliges cada día en Hoy.</p></CardHeader><CardContent className="space-y-5 p-5"><div><label className="field-label text-[#d7e4d2]">Etapa</label><div className="mt-2 flex flex-wrap gap-2">{stages.map(stage => <button key={stage} onClick={() => updateProfile("stage", stage)} className={`choice-pill ${profile.stage === stage ? "choice-pill-selected" : ""}`}>{stage}</button>)}</div></div><div><label className="field-label text-[#d7e4d2]">Cómo quieres ofrecer</label><div className="mt-2 grid grid-cols-3 gap-1.5">{methods.map(method => <button key={method} onClick={() => updateProfile("method", method)} className={`method-pill ${profile.method === method ? "method-pill-selected" : ""}`}>{method}</button>)}</div></div><div><label className="field-label text-[#d7e4d2]">A evitar</label><div className="mt-2 flex flex-wrap gap-2">{profile.avoid.map(item => <button key={item} onClick={() => toggleListValue("avoid", item)} className="filter-chip filter-chip-danger">{item}<X size={11} /></button>)}</div><div className="mt-2 flex gap-2"><Input value={customAvoid} onChange={event => setCustomAvoid(event.target.value)} onKeyDown={event => event.key === "Enter" && addCustom("avoid", customAvoid, setCustomAvoid)} placeholder="Ej. soya, nueces" className="h-9 min-w-0 rounded-xl border-white/20 bg-white/10 text-xs text-white placeholder:text-[#d7e4d2]" /><Button type="button" onClick={() => addCustom("avoid", customAvoid, setCustomAvoid)} size="sm" className="h-9 shrink-0 bg-white/15 text-white hover:bg-white/25"><Plus size={13} />Agregar</Button></div></div><div><label className="field-label text-[#d7e4d2]">Disponibles</label><div className="mt-2 flex flex-wrap gap-2">{profile.available.map(item => <button key={item} onClick={() => toggleListValue("available", item)} className="filter-chip filter-chip-selected">{item}<X size={11} /></button>)}</div><div className="mt-2 flex gap-2"><Input value={customAvailable} onChange={event => setCustomAvailable(event.target.value)} onKeyDown={event => event.key === "Enter" && addCustom("available", customAvailable, setCustomAvailable)} placeholder="Ej. mango, avena" className="h-9 min-w-0 rounded-xl border-white/20 bg-white/10 text-xs text-white placeholder:text-[#d7e4d2]" /><Button type="button" onClick={() => addCustom("available", customAvailable, setCustomAvailable)} size="sm" className="h-9 shrink-0 bg-white/15 text-white hover:bg-white/25"><Plus size={13} />Agregar</Button></div></div><Button onClick={generateWeek} className="w-full bg-[#f3bd62] font-semibold text-[#23352f] shadow-none hover:bg-[#facd79]"><Sparkles size={16} />Crear mi semana</Button><p className="text-center text-[11px] leading-4 text-[#c8d8c3]">Tu menú se puede cambiar sin perder el resto del plan.</p></CardContent></Card>
            <Card className="border-[#e0e5dc] bg-white/70 shadow-sm"><CardContent className="p-5"><div className="flex items-center justify-between"><div><p className="text-sm font-semibold text-[#49654f]">Esta semana</p><p className="mt-1 text-xs text-[#849187]">{planRecipeCount} comidas en tu plan</p></div><span className="rounded-full bg-[#eff4eb] p-2 text-[#668564]"><CalendarDays size={18} /></span></div><div className="mt-4"><ProgressBar completed={completedShopping} total={shopping.length} /></div><div className="mt-2 flex justify-between text-[11px] text-[#8b988e]"><span>Compra</span><span>{shopping.length ? Math.round((completedShopping / shopping.length) * 100) : 0}%</span></div></CardContent></Card>
            <div className="hidden rounded-2xl border border-[#e6e8df] bg-[#f2f5ec] p-5 lg:block"><div className="flex items-center gap-2 text-[#56725b]"><BookOpen size={17} /><span className="text-xs font-semibold uppercase tracking-[0.14em]">No es un recetario</span></div><p className="mt-3 font-display text-lg leading-6 text-[#38523e]">Es una herramienta para decidir, organizar y comprar.</p><p className="mt-2 text-xs leading-5 text-[#738276]">Menos recetas guardadas. Menos decisiones pendientes.</p><p className="mt-3 text-[11px] leading-4 text-[#738276]">Con BLW verás solo preparaciones blandas en tiras o piezas para agarrar.</p></div>
          </aside>

          <section className="min-w-0">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="hidden"><TabsTrigger value="inicio" className="tab-trigger"><Sparkles size={15} />Hoy</TabsTrigger><TabsTrigger value="semana" className="tab-trigger"><CalendarDays size={15} />Semana</TabsTrigger><TabsTrigger value="compra" className="tab-trigger"><ShoppingBasket size={15} />Compra</TabsTrigger><TabsTrigger value="guardados" className="tab-trigger"><Heart size={15} />Guardados</TabsTrigger></TabsList>
              <TabsContent value="inicio" className="mt-0 space-y-6">
                <Card className="overflow-hidden border-[#e0e5dc] bg-white shadow-[0_16px_40px_rgba(50,67,54,0.06)]"><CardContent className="p-5 sm:p-7"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start"><div><div className="section-kicker"><span className="section-kicker-icon"><Search size={14} /></span>La pregunta de hoy</div><h2 className="mt-3 font-display text-2xl font-semibold tracking-[-0.03em] text-[#23352f]">¿Qué le doy hoy?</h2><p className="mt-2 max-w-[530px] text-sm leading-6 text-[#75837a]">Busca una opción compatible con la etapa, lo que tienes y el tiempo que te queda. Menú bebés filtra antes de hacerte decidir.</p></div><Badge className="w-fit rounded-full bg-[#f4e2d9] px-3 py-1 text-[#a8614c] hover:bg-[#f4e2d9]">{filteredRecipes.length} opciones compatibles · {recipeCatalog.length} recetas</Badge></div><div className="mt-6 grid gap-3 sm:grid-cols-[1fr_170px_190px]"><div className="relative"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#99a69c]" size={17} /><Input value={search} onChange={event => setSearch(event.target.value)} placeholder="Busca por ingrediente o preparación" className="h-12 rounded-xl border-[#e0e5dc] pl-10 text-sm shadow-none focus-visible:ring-[#9db6a0]" /></div><select value={mealFilter} onChange={event => setMealFilter(event.target.value as MealKey | "todos")} aria-label="Tipo de comida" className="h-12 rounded-xl border border-[#e0e5dc] bg-white px-3 text-sm text-[#55705d] outline-none"><option value="todos">Todas las comidas</option>{mealOrder.map(meal => <option key={meal} value={meal}>{mealLabels[meal]}</option>)}</select><label className="flex h-12 items-center gap-2 rounded-xl border border-[#e0e5dc] bg-white px-3 text-xs font-semibold text-[#6a806f]">Tiempo para cocinar hoy<select value={profile.time} onChange={event => updateProfile("time", event.target.value)} aria-label="Tiempo para cocinar hoy" className="min-w-0 flex-1 bg-transparent text-sm font-normal text-[#55705d] outline-none"><option>Cualquier tiempo</option><option>Menos de 15 min</option><option>15 a 30 min</option><option>Más de 30 min</option></select></label></div><button onClick={() => setShowAllFilters(value => !value)} className="mt-3 flex items-center gap-2 text-xs font-semibold text-[#6a856e]">Más filtros <ChevronDown className={showAllFilters ? "rotate-180 transition" : "transition"} size={14} /></button>{showAllFilters && <div className="mt-4 rounded-2xl bg-[#f0f2ed] p-4"><p className="field-label text-[#6f8574]">Ingredientes disponibles</p><div className="mt-3 flex flex-wrap gap-2">{availableOptions.map(item => <button key={item} onClick={() => toggleListValue("available", item)} className={`filter-chip ${profile.available.includes(item) ? "filter-chip-selected" : ""}`}>{profile.available.includes(item) && <Check size={13} />}{item}</button>)}</div><p className="mt-4 field-label text-[#6f8574]">Alimentos a evitar</p><div className="mt-3 flex flex-wrap gap-2">{avoidOptions.map(item => <button key={item} onClick={() => toggleListValue("avoid", item)} className={`filter-chip ${profile.avoid.includes(item) ? "filter-chip-danger" : ""}`}>{profile.avoid.includes(item) && <Check size={13} />}{item}</button>)}</div></div>}</CardContent></Card>
                <div className="grid gap-4 sm:grid-cols-3">{todayOptions.map(recipe => <RecipeCard key={recipe.id} recipe={recipe} favorite={favorites.includes(recipe.id)} onOpen={() => setSelectedRecipe(recipe)} onFavorite={() => toggleFavorite(recipe.id)} compact />)}</div>
                {!todayOptions.length && <EmptyState title="No encontramos una opción con esos filtros" description="Prueba quitar un ingrediente a evitar o ampliar el tiempo disponible." action="Limpiar filtros" onAction={() => { setSearch(""); setMealFilter("todos"); setProfile(current => ({ ...current, avoid: [], available: [] })); }} />}
                <Card className="border-[#e5e9df] bg-[#f2f6ef] shadow-none"><CardContent className="flex flex-col justify-between gap-4 p-5 sm:flex-row sm:items-center"><div className="flex gap-3"><span className="rounded-xl bg-white p-2.5 text-[#6c8b6c] shadow-sm"><CalendarDays size={18} /></span><div><p className="font-semibold text-[#46624d]">¿Quieres dejar de decidir cada día?</p><p className="mt-1 text-sm text-[#6f8574]">Crea una semana y ajusta solo lo que cambie.</p></div></div><Button onClick={generateWeek} variant="outline" className="border-[#c8d9c4] bg-white text-[#537154] hover:bg-white"><span>Crear mi semana</span><ArrowRight size={15} /></Button></CardContent></Card>
              </TabsContent>
              <TabsContent value="semana" className="mt-0 space-y-5">
                <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="section-kicker"><span className="section-kicker-icon"><CalendarDays size={14} /></span>Tu plan editable</div><h2 className="mt-3 font-display text-3xl font-semibold tracking-[-0.03em] text-[#23352f]">Mi semana</h2><p className="mt-2 text-sm text-[#75837a]">Cambia una sola comida cuando tu día cambie. Lo demás queda en su lugar.</p></div><div className="flex items-center gap-1 rounded-xl border border-[#eadfe2] bg-white p-1"><button onClick={() => setWeekView("list")} className={`view-toggle ${weekView === "list" ? "view-toggle-active" : ""}`}><Utensils size={14} />Lista</button><button onClick={() => setWeekView("calendar")} className={`view-toggle ${weekView === "calendar" ? "view-toggle-active" : ""}`}><CalendarRange size={14} />Calendario</button></div><Button onClick={generateWeek} className="w-fit bg-[#7b5269] text-white hover:bg-[#654256]"><RefreshCw size={15} />Regenerar semana</Button></div>
                {weekView === "calendar" ? <CalendarView week={week} onOpen={id => setSelectedRecipe(recipeById(id))} onChange={replaceMeal} /> : <div className="space-y-3">{week.map((day, dayIndex) => <Card key={day.day} className="border-[#e0e5dc] bg-white shadow-sm"><CardContent className="p-4 sm:p-5"><div className="mb-4 flex items-center justify-between"><div><p className="font-display text-lg font-semibold text-[#38523e]">{day.day}</p><p className="text-xs text-[#9aa69c]">{dayIndex === 0 ? "Empieza con una opción suave" : "Una decisión menos para hoy"}</p></div><span className="rounded-full bg-[#f0f2ed] px-3 py-1 text-[11px] font-semibold text-[#718872]">{dayIndex + 1}</span></div><div className="grid gap-3 md:grid-cols-3">{mealOrder.map(meal => <MealCard key={meal} meal={meal} recipe={recipeById(day.meals[meal])} onOpen={() => setSelectedRecipe(recipeById(day.meals[meal]))} onChange={() => replaceMeal(dayIndex, meal)} />)}</div></CardContent></Card>)}</div>}
              </TabsContent>
              <TabsContent value="compra" className="mt-0 space-y-5"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><div className="section-kicker"><span className="section-kicker-icon"><ShoppingBasket size={14} /></span>Calculada desde tu menú</div><h2 className="mt-3 font-display text-3xl font-semibold tracking-[-0.03em] text-[#23352f]">Mi compra</h2><p className="mt-2 text-sm text-[#75837a]">Marca lo que ya tienes. Esta lista cambia cuando cambias una comida.</p><div className="mt-4 rounded-xl border border-[#e5e9df] bg-[#f6f8f2] px-4 py-3 text-xs leading-5 text-[#718078]"><strong className="text-[#557257]">Nota sobre cantidades:</strong> los totales son una estimación de ingredientes para preparar tu menú semanal. No indican cuánto debe comer tu bebé ni son una porción obligatoria; ofrece cantidades pequeñas y ajusta según sus señales de hambre, saciedad y etapa.</div></div><Button onClick={() => { navigator.clipboard?.writeText(shopping.map(item => `${item.checked ? "☑" : "☐"} ${item.name}, ${item.quantity}`).join("\n")); toast.success("Lista copiada", { description: "Ya puedes pegarla en WhatsApp." }); }} variant="outline" className="w-fit border-[#d8dfd3] bg-white text-[#537154]"><BookOpen size={15} />Copiar lista</Button></div><Card className="border-[#e0e5dc] bg-white shadow-sm"><CardContent className="p-5 sm:p-7"><div className="mb-6 flex items-center justify-between"><div><p className="text-sm font-semibold text-[#46624d]">Compra de esta semana</p><p className="mt-1 text-xs text-[#96a198]">{shopping.length} ingredientes para {planRecipeCount} comidas</p></div><span className="text-sm font-semibold text-[#648064]">{completedShopping}/{shopping.length}</span></div><ProgressBar completed={completedShopping} total={shopping.length} /><div className="mt-7 grid gap-7 sm:grid-cols-2">{(["Frutas", "Verduras", "Proteínas", "Cereales y otros"] as Category[]).map(category => { const items = shopping.filter(item => item.category === category); if (!items.length) return null; return <div key={category}><p className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#8a988d]"><span className="h-1.5 w-1.5 rounded-full bg-[#e6b15c]" />{category}</p><div className="space-y-2">{items.map(item => <label key={item.name} className={`shopping-row ${item.checked ? "shopping-row-done" : ""}`}><Checkbox checked={item.checked} onCheckedChange={() => toggleShopping(item.name)} /><span className="min-w-0 flex-1 text-sm">{item.name}</span><span className="text-xs text-[#94a097]">{item.quantity}</span></label>)}</div></div>; })}</div></CardContent></Card></TabsContent>
              <TabsContent value="guardados" className="mt-0 space-y-5"><div><div className="section-kicker"><span className="section-kicker-icon"><Heart size={14} /></span>Para volver cuando funcione</div><h2 className="mt-3 font-display text-3xl font-semibold tracking-[-0.03em] text-[#23352f]">Guardados</h2><p className="mt-2 text-sm text-[#75837a]">Tus favoritas y las comidas que ya sabes que puedes repetir.</p></div>{favoriteRecipes.length ? <div className="grid gap-4 sm:grid-cols-2">{favoriteRecipes.map(recipe => <RecipeCard key={recipe.id} recipe={recipe} favorite onOpen={() => setSelectedRecipe(recipe)} onFavorite={() => toggleFavorite(recipe.id)} />)}</div> : <EmptyState title="Todavía no has guardado comidas" description="Guarda una receta cuando encuentres una que encaje contigo." action="Ver opciones" onAction={() => setActiveTab("inicio")} />}</TabsContent>
            </Tabs>
          </section>
        </div>

        <section className="mt-10 grid gap-4 border-t border-[#e0e5dc] pt-8 sm:grid-cols-3"><TrustItem icon={<Sparkles size={17} />} title="Decide en minutos" text="Filtra por etapa, ingredientes y tiempo disponible." /><TrustItem icon={<RefreshCw size={17} />} title="Cambia sin rehacer" text="Una comida puede cambiar sin borrar toda tu semana." /><TrustItem icon={<ShoppingBasket size={17} />} title="Compra lo que sí usas" text="La lista se calcula a partir de tu menú final." /></section>
        <div className="mt-8 rounded-2xl border border-[#ebe9df] bg-[#f7f6f0] p-5 text-xs leading-5 text-[#7f8b82]"><div className="flex items-center gap-2 font-semibold text-[#617363]"><span className="rounded-full bg-white p-1.5"><BookOpen size={13} /></span>Información importante</div><p className="mt-3">Menú bebés ofrece organización e información general. No diagnostica alergias ni sustituye al pediatra o nutricionista. Las familias con alergias diagnosticadas, prematuridad, bajo peso, anemia, dificultades para tragar, vómitos repetidos o indicaciones médicas deben consultar a un profesional antes de usar cualquier plan.</p></div>
      </main>

      {replacement && <ReplacementDialog meal={replacement.meal} options={replacement.options} onChoose={chooseReplacement} onClose={() => setReplacement(null)} />}
      {selectedRecipe && <RecipeDialog recipe={selectedRecipe} favorite={favorites.includes(selectedRecipe.id)} onClose={() => setSelectedRecipe(null)} onFavorite={() => toggleFavorite(selectedRecipe.id)} onAdd={() => { addRecipeToWeek(selectedRecipe); setSelectedRecipe(null); setActiveTab("semana"); toast.success("Añadida a tu semana", { description: "La añadimos al primer día de tu plan." }); }} />}
      <nav className="bottom-nav">{navItems.map(item => { const Icon = item.icon; return <button key={item.id} onClick={() => setActiveTab(item.id)} className={`bottom-nav-item ${activeTab === item.id ? "bottom-nav-item-active" : ""}`}><Icon size={19} /><span>{item.label === "Mi semana" ? "Semana" : item.label === "Mi compra" ? "Compra" : item.label}</span></button>; })}</nav>
    </div>
  );
}

function RecipeCard({ recipe, favorite, onOpen, onFavorite, compact = false }: { recipe: Recipe; favorite: boolean; onOpen: () => void; onFavorite: () => void; compact?: boolean }) {
  return <Card className={`recipe-card group overflow-hidden border-[#e0e5dc] bg-white shadow-sm ${compact ? "" : ""}`}><div className="relative cursor-pointer" onClick={onOpen}><img src={recipe.image} alt={recipe.title} className={`w-full object-cover transition duration-500 group-hover:scale-[1.03] ${compact ? "h-40" : "h-48"}`} /><div className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-[#668064]">{recipe.stage}</div><button onClick={event => { event.stopPropagation(); onFavorite(); }} className={`absolute right-3 top-3 rounded-full p-2 backdrop-blur transition ${favorite ? "bg-[#f8e8db] text-[#c27859]" : "bg-white/85 text-[#819088] hover:text-[#c27859]"}`} title={favorite ? "Quitar de guardados" : "Guardar receta"}><Heart size={16} fill={favorite ? "currentColor" : "none"} /></button></div><CardContent className="p-4"><div className="flex items-start justify-between gap-3"><div><h3 className="font-display text-[17px] font-semibold leading-5 text-[#314b38]">{recipe.title}</h3><p className="mt-2 line-clamp-2 text-xs leading-5 text-[#849187]">{recipe.description}</p></div><span className="flex shrink-0 items-center gap-1 text-xs font-semibold text-[#9a7b46]"><Clock3 size={13} />{recipe.minutes}m</span></div><div className="mt-4 flex items-center justify-between"><span className="text-[11px] font-medium text-[#91a097]">{recipe.texture}</span>{blwRecipeIds.has(recipe.id) && <span className="ml-2 rounded-full bg-[#edf2e8] px-2 py-1 text-[9px] font-bold uppercase tracking-[.1em] text-[#60785f]">BLW</span>}<button onClick={onOpen} className="flex items-center gap-1 text-xs font-bold text-[#668064] transition hover:text-[#3e5f46]">Ver receta <ArrowRight size={13} /></button></div></CardContent></Card>;
}

function MealCard({ meal, recipe, onOpen, onChange }: { meal: MealKey; recipe: Recipe; onOpen: () => void; onChange: () => void }) {
  return <div className="meal-card"><button onClick={onOpen} className="relative block w-full overflow-hidden rounded-xl text-left"><img src={recipe.image} alt={recipe.title} className="h-28 w-full object-cover" /><span className="absolute left-2 top-2 rounded-full bg-white/90 px-2 py-1 text-[9px] font-bold uppercase tracking-[0.1em] text-[#70886f]">{mealLabels[meal]}</span></button><div className="mt-3"><p className="line-clamp-2 min-h-10 text-sm font-semibold leading-5 text-[#3c5743]">{recipe.title}</p><div className="mt-2 flex items-center justify-between"><span className="flex items-center gap-1 text-[11px] text-[#96a198]"><Clock3 size={12} />{recipe.minutes} min</span><button onClick={onChange} className="flex items-center gap-1 text-[11px] font-bold text-[#b07b35] hover:text-[#8d5d24]"><RefreshCw size={12} />Cambiar</button></div></div></div>;
}

function ReplacementDialog({ meal, options, onChoose, onClose }: { meal: MealKey; options: Recipe[]; onChoose: (id: string) => void; onClose: () => void }) {
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#1d3026]/35 p-0 backdrop-blur-[2px] sm:items-center sm:p-5" onClick={onClose}><div className="max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-t-[28px] bg-[#fbfaf5] p-5 shadow-2xl sm:rounded-[28px] sm:p-7" onClick={event => event.stopPropagation()}><div className="flex items-start justify-between gap-4"><div><p className="section-kicker"><span className="section-kicker-icon"><RefreshCw size={14} /></span>Variar {mealLabels[meal].toLowerCase()}</p><h2 className="mt-3 font-display text-2xl font-semibold text-[#3d2937]">Elige una nueva opción</h2><p className="mt-2 text-sm text-[#75837a]">Te mostramos {options.length} alternativas compatibles. Solo cambia esta comida.</p></div><button onClick={onClose} className="rounded-full p-2 text-[#8c7482] hover:bg-[#f8eef2]" aria-label="Cerrar"><X size={18} /></button></div><div className="mt-6 grid gap-4 sm:grid-cols-3">{options.map(recipe => <button key={recipe.id} onClick={() => onChoose(recipe.id)} className="overflow-hidden rounded-2xl border border-[#e0e5dc] bg-white text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"><img src={recipe.image} alt={recipe.title} className="h-32 w-full object-cover" /><div className="p-3"><p className="font-display text-sm font-semibold leading-5 text-[#3c5743]">{recipe.title}</p><p className="mt-2 text-xs text-[#849187]">{recipe.minutes} min · {recipe.texture}</p><span className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-[#668064]">Elegir <ArrowRight size={12} /></span></div></button>)}</div></div></div>;
}
function RecipeDialog({ recipe, favorite, onClose, onFavorite, onAdd }: { recipe: Recipe; favorite: boolean; onClose: () => void; onFavorite: () => void; onAdd: () => void }) {
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#1d3026]/35 p-0 backdrop-blur-[2px] sm:items-center sm:p-5" onClick={onClose}><div className="max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-t-[28px] bg-[#fbfaf5] shadow-2xl sm:rounded-[28px]" onClick={event => event.stopPropagation()}><div className="relative"><img src={recipe.image} alt={recipe.title} className="h-56 w-full object-cover sm:h-72" /><button onClick={onClose} className="absolute right-4 top-4 rounded-full bg-white/90 p-2 text-[#46624d] shadow-sm"><X size={18} /></button><div className="absolute bottom-4 left-5 right-5 flex items-end justify-between"><span className="rounded-full bg-white/90 px-3 py-1.5 text-xs font-bold text-[#668064]">{recipe.stage}</span><button onClick={onFavorite} className={`rounded-full p-2.5 shadow-sm ${favorite ? "bg-[#f8e8db] text-[#c27859]" : "bg-white/90 text-[#6f8574]"}`}><Heart size={18} fill={favorite ? "currentColor" : "none"} /></button></div></div><div className="p-5 sm:p-7"><div className="flex flex-wrap items-start justify-between gap-4"><div><h2 className="font-display text-3xl font-semibold tracking-[-0.035em] text-[#294334]">{recipe.title}</h2><div className="mt-3 flex flex-wrap gap-2"><span className="detail-pill"><Clock3 size={13} />{recipe.minutes} minutos</span><span className="detail-pill"><Utensils size={13} />{recipe.texture}</span><span className="detail-pill"><ShoppingBasket size={13} />Rinde aprox. {recipe.yield ?? 2} porciones pequeñas</span>{recipe.tags.map(tag => <span className="detail-pill" key={tag}>{tag}</span>)}</div></div></div><p className="mt-5 text-sm leading-6 text-[#718078]">{recipe.description}</p><div className="mt-6 grid gap-5 sm:grid-cols-2"><div><h3 className="font-display text-lg font-semibold text-[#3e5c45]">Ingredientes</h3><ul className="mt-3 space-y-2 text-sm text-[#718078]">{recipe.ingredients.map(item => <li key={item} className="flex items-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#d4a95d]" />{item}</li>)}</ul></div><div><h3 className="font-display text-lg font-semibold text-[#3e5c45]">Cómo prepararlo</h3><p className="mt-3 text-sm leading-6 text-[#718078]">{recipe.preparation}</p></div></div><div className="mt-6 rounded-2xl border border-[#e9e6db] bg-[#f0f2ed] p-4 text-xs leading-5 text-[#718078]"><strong className="text-[#557257]">Porción orientativa:</strong> la receta indica ingredientes para preparar una pequeña tanda, no una cantidad que el bebé deba terminar. Empieza con poco y adapta según la etapa, el desarrollo, sus señales de hambre y saciedad y las indicaciones de su profesional de salud. Supervisa siempre la comida.</div><div className="mt-6 flex flex-col gap-3 sm:flex-row"><Button onClick={onAdd} className="flex-1 bg-[#466d51] text-white hover:bg-[#385a42]"><CalendarDays size={16} />Añadir a mi semana</Button><Button onClick={onClose} variant="outline" className="border-[#d8dfd3] text-[#557257]">Cerrar</Button></div></div></div></div>;
}

function ProfileDialog({ profile, onClose, updateProfile, toggleListValue, onSave }: { profile: Profile; onClose: () => void; updateProfile: (key: keyof Profile, value: string | string[]) => void; toggleListValue: (key: "avoid" | "available", value: string) => void; onSave: () => void }) {
  const [customAvoid, setCustomAvoid] = useState("");
  const [customAvailable, setCustomAvailable] = useState("");
  const addCustom = (key: "avoid" | "available", value: string, clear: (value: string) => void) => { const clean = value.trim(); if (!clean) return; const exists = profile[key].some(item => normalizeIngredient(item) === normalizeIngredient(clean)); if (!exists) updateProfile(key, [...profile[key], clean]); clear(""); };
  return <div className="fixed inset-0 z-50 flex items-end justify-center bg-[#34242d]/35 p-0 backdrop-blur-[2px] sm:items-center sm:p-5" onClick={onClose}><div className="w-full max-w-xl rounded-t-[28px] bg-[#fffdfb] p-5 shadow-2xl sm:rounded-[28px] sm:p-7" onClick={event => event.stopPropagation()}><div className="flex items-start justify-between"><div><BrandLogo /><div className="section-kicker mt-5"><span className="section-kicker-icon"><Baby size={14} /></span>Perfil del bebé</div><h2 className="mt-3 font-display text-2xl font-semibold text-[#3d2937]">Personaliza el perfil del bebé</h2></div><button onClick={onClose} className="rounded-full p-2 text-[#8c7482] hover:bg-[#f8eef2]"><X size={18} /></button></div><div className="mt-6 space-y-5"><div><label className="field-label text-[#8c7482]">Etapa</label><div className="mt-2 flex flex-wrap gap-2">{stages.map(stage => <button key={stage} onClick={() => updateProfile("stage", stage)} className={`filter-chip ${profile.stage === stage ? "filter-chip-selected" : ""}`}>{stage}</button>)}</div></div><div><label className="field-label text-[#8c7482]">Forma de ofrecer</label><div className="mt-2 grid grid-cols-3 gap-2">{methods.map(method => <button key={method} onClick={() => updateProfile("method", method)} className={`method-pill light ${profile.method === method ? "method-pill-selected-light" : ""}`}>{method}</button>)}</div></div><div><label className="field-label text-[#8c7482]">Alimentos a evitar</label><div className="mt-2 flex flex-wrap gap-2">{profile.avoid.map(item => <button key={item} onClick={() => toggleListValue("avoid", item)} className="filter-chip filter-chip-danger"><Check size={13} />{item}<X size={12} /></button>)}<div className="flex w-full gap-2"><Input value={customAvoid} onChange={event => setCustomAvoid(event.target.value)} onKeyDown={event => event.key === "Enter" && addCustom("avoid", customAvoid, setCustomAvoid)} placeholder="Ej. soya, nueces..." className="h-9 rounded-xl border-[#eadfe2] bg-white text-xs" /><Button type="button" onClick={() => addCustom("avoid", customAvoid, setCustomAvoid)} size="sm" className="h-9 bg-[#7b5269] text-white hover:bg-[#654256]"><Plus size={14} />Agregar</Button></div></div></div><div><label className="field-label text-[#8c7482]">Alimentos disponibles</label><div className="mt-2 flex flex-wrap gap-2">{profile.available.map(item => <button key={item} onClick={() => toggleListValue("available", item)} className="filter-chip filter-chip-selected"><Check size={13} />{item}<X size={12} /></button>)}<div className="flex w-full gap-2"><Input value={customAvailable} onChange={event => setCustomAvailable(event.target.value)} onKeyDown={event => event.key === "Enter" && addCustom("available", customAvailable, setCustomAvailable)} placeholder="Ej. soya, mango..." className="h-9 rounded-xl border-[#eadfe2] bg-white text-xs" /><Button type="button" onClick={() => addCustom("available", customAvailable, setCustomAvailable)} size="sm" className="h-9 bg-[#7b5269] text-white hover:bg-[#654256]"><Plus size={14} />Agregar</Button></div></div></div></div><Button onClick={onSave} className="mt-7 w-full bg-[#7b5269] text-white hover:bg-[#654256]">Guardar perfil</Button></div></div>;
}

function CalendarView({ week, onOpen, onChange }: { week: WeekDay[]; onOpen: (id: string) => void; onChange: (dayIndex: number, meal: MealKey) => void }) {
  return <Card className="border-[#eadfe2] bg-white shadow-sm"><CardContent className="overflow-x-auto p-3 sm:p-5"><div className="calendar-grid min-w-[760px]"><div className="calendar-corner"><CalendarRange size={16} /><span>Semana</span></div>{week.map(day => <div key={day.day} className="calendar-day-header"><span>{day.day.slice(0, 3)}</span><strong>{week.indexOf(day) + 1}</strong></div>)}{mealOrder.map(meal => <Fragment key={meal}><div className="calendar-meal-label">{mealLabels[meal]}</div>{week.map((day, dayIndex) => { const recipe = recipeById(day.meals[meal]); return <div key={`${day.day}-${meal}`} className="calendar-cell"><button onClick={() => onOpen(recipe.id)} className="calendar-recipe"><img src={recipe.image} alt={recipe.title} /><span>{recipe.title}</span></button><button onClick={() => onChange(dayIndex, meal)} className="calendar-change"><RefreshCw size={12} />Cambiar</button></div>; })}</Fragment>)}</div></CardContent></Card>;
}

function EmptyState({ title, description, action, onAction }: { title: string; description: string; action: string; onAction: () => void }) {
  return <div className="rounded-2xl border border-dashed border-[#dce3d8] bg-white/60 p-10 text-center"><span className="mx-auto flex h-11 w-11 items-center justify-center rounded-full bg-[#eef4eb] text-[#6e8d6d]"><Search size={19} /></span><h3 className="mt-4 font-display text-lg font-semibold text-[#46624d]">{title}</h3><p className="mx-auto mt-2 max-w-sm text-sm leading-6 text-[#829087]">{description}</p><Button onClick={onAction} variant="outline" className="mt-5 border-[#cfdcc9] text-[#557257]">{action}</Button></div>;
}

function TrustItem({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return <div className="flex gap-3"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#edf3e9] text-[#6c8a6c]">{icon}</span><div><p className="text-sm font-semibold text-[#49654f]">{title}</p><p className="mt-1 text-xs leading-5 text-[#829087]">{text}</p></div></div>;
}
