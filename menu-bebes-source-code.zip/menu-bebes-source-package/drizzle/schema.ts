import { int, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: varchar("role", { length: 16 }).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const userAppState = mysqlTable("user_app_state", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  profileJson: text("profileJson"),
  planJson: text("planJson"),
  favoritesJson: text("favoritesJson"),
  shoppingJson: text("shoppingJson"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type UserAppState = typeof userAppState.$inferSelect;
export type InsertUserAppState = typeof userAppState.$inferInsert;

export type AppStatePayload = {
  profile?: unknown;
  plan?: unknown;
  favorites?: unknown;
  shopping?: unknown;
};

export type AppStateRecord = {
  profile: unknown | null;
  plan: unknown | null;
  favorites: unknown | null;
  shopping: unknown | null;
  updatedAt: Date | null;
};

/**
 * Core identity and application state tables. Recipe content is intentionally
 * served from the reviewed catalog in the client so the MVP remains fast.
 */
