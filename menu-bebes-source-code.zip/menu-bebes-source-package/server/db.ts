import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, userAppState, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserAppState(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const rows = await db.select().from(userAppState).where(eq(userAppState.userId, userId)).limit(1);
  const row = rows[0];
  if (!row) return undefined;
  return {
    profile: row.profileJson ? JSON.parse(row.profileJson) : null,
    plan: row.planJson ? JSON.parse(row.planJson) : null,
    favorites: row.favoritesJson ? JSON.parse(row.favoritesJson) : null,
    shopping: row.shoppingJson ? JSON.parse(row.shoppingJson) : null,
    updatedAt: row.updatedAt,
  };
}

export async function saveUserAppState(userId: number, payload: Record<string, unknown>) {
  const db = await getDb();
  if (!db) return { persisted: false } as const;
  const values = {
    userId,
    profileJson: payload.profile === undefined ? undefined : JSON.stringify(payload.profile),
    planJson: payload.plan === undefined ? undefined : JSON.stringify(payload.plan),
    favoritesJson: payload.favorites === undefined ? undefined : JSON.stringify(payload.favorites),
    shoppingJson: payload.shopping === undefined ? undefined : JSON.stringify(payload.shopping),
  };
  await db.insert(userAppState).values(values).onDuplicateKeyUpdate({
    set: {
      ...(values.profileJson === undefined ? {} : { profileJson: values.profileJson }),
      ...(values.planJson === undefined ? {} : { planJson: values.planJson }),
      ...(values.favoritesJson === undefined ? {} : { favoritesJson: values.favoritesJson }),
      ...(values.shoppingJson === undefined ? {} : { shoppingJson: values.shoppingJson }),
      updatedAt: new Date(),
    },
  });
  return { persisted: true } as const;
}
