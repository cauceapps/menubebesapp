import { COOKIE_NAME } from "@shared/const";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { getUserAppState, saveUserAppState } from "./db";

const stateInput = z.object({
  profile: z.unknown().optional(),
  plan: z.unknown().optional(),
  favorites: z.unknown().optional(),
  shopping: z.unknown().optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  appState: router({
    get: protectedProcedure.query(({ ctx }) => getUserAppState(ctx.user.id)),
    save: protectedProcedure.input(stateInput).mutation(({ ctx, input }) => saveUserAppState(ctx.user.id, input)),
  }),
});

export type AppRouter = typeof appRouter;
