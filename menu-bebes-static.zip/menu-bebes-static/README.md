# Menú bebés — versión estática

Esta carpeta contiene el resultado compilado de la interfaz web de Menú bebés.

## Publicar en GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube todos los archivos de esta carpeta a la raíz del repositorio.
3. En GitHub, abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/root`.
6. Guarda los cambios y espera a que GitHub genere la URL pública.

También puedes subir estos archivos a Netlify, Vercel, Cloudflare Pages o cualquier hosting estático.

## Importante

Este paquete contiene el frontend compilado y sirve para visualizar la interfaz. La versión completa de Menú bebés utiliza React, un servidor Node/Express, tRPC, autenticación y base de datos para guardar perfiles, semanas, favoritos y listas de compra.

Para conservar esas funciones debes desplegar el paquete de código fuente completo con un servicio que soporte Node.js y configurar sus variables de entorno. GitHub Pages por sí solo no ejecuta el backend.
